# Checklist de deploy e plano de rollback (fatia 1)

> Nada aqui foi executado contra um ambiente real. Marque cada item ao executar.

## Antes do primeiro deploy
- [ ] Criar o projeto Supabase (ambientes separados: dev, teste, producao).
- [ ] Authentication > Providers > Email: **habilitar confirmacao de e-mail**.
- [ ] Authentication > URL Configuration: Site URL = `NEXT_PUBLIC_APP_URL`; adicionar `NEXT_PUBLIC_APP_URL/auth/callback` aos Redirect URLs.
- [ ] Aplicar as migracoes (`supabase link` + `supabase db push`, ou colar os 3 arquivos de `supabase/migrations` em ordem no SQL Editor).
- [ ] Conferir que a migracao rodou como o papel `postgres` (a protecao do OWNER depende disso).
- [ ] Configurar as variaveis na Vercel (Production e Preview): `NEXT_PUBLIC_APP_URL`, `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`.
- [ ] Confirmar que `.env.local` nao esta no Git (`git status`) e que nenhuma chave aparece no historico.
- [ ] CI verde (`typecheck`, `test`, `build`).

## Inicializar o OWNER (uma vez por ambiente)
1. Em `/signup`, crie a conta com o e-mail do proprietario e **confirme o e-mail** pelo link recebido.
2. No seu computador, em `.env.local`, defina `INITIAL_OWNER_EMAIL`, `NEXT_PUBLIC_SUPABASE_URL` e `SUPABASE_SERVICE_ROLE_KEY` do ambiente alvo.
3. `npm run bootstrap-owner`. Resultados: `owner_assigned`, `already_owner` (idempotente) ou um erro explicativo.
4. Entre em `/dashboard`: o plano deve aparecer como "OWNER — Acesso administrativo" e o link "Administração" leva a `/admin`.
5. Confira em `/admin/audit` o registro `owner.bootstrap`.
6. Ative a verificacao em duas etapas no e-mail do proprietario.

## Verificacao pos-deploy
- [ ] Anonimo em `/admin` e `/dashboard` e redirecionado para `/login`.
- [ ] Conta comum em `/admin` volta para `/dashboard` com "Acesso negado".
- [ ] Conta comum nao consegue alterar `role`/`status` via API do Supabase com a anon key.
- [ ] OWNER em `/dashboard/subscription` ve a isencao de cobranca.

## Rollback
- **Aplicacao**: na Vercel, promova o deploy anterior (Deployments > Promote to Production). As rotas desta fatia sao compativeis com o schema anterior.
- **Banco**: as migracoes 1-3 so criam objetos novos. Antes de aplicar em producao, faca backup (Supabase > Database > Backups) ou `pg_dump`. Para desfazer em ambiente sem dados reais, restaure o backup ou remova os objetos criados (`drop table ... cascade`, `drop type`, `drop function`) em ordem inversa. Nunca desfaça migracoes em producao com dados de clientes sem restaurar de backup.
- **OWNER**: trocar de proprietario exige migracao/SQL manual executado como `postgres` (nem o `service_role` consegue, por projeto).
- **Segredos expostos**: gire a `SUPABASE_SERVICE_ROLE_KEY` no painel do Supabase e atualize a Vercel imediatamente.
