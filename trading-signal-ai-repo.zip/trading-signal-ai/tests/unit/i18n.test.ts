import { describe, it, expect } from "vitest";
import ptBR from "@/i18n/pt-BR";
import en from "@/i18n/en";
import { fmt } from "@/i18n";
import { GRANTABLE_PERMISSIONS } from "@/lib/authz/types";
import { PLAN_KEYS } from "@/lib/authz/plans";

function flatten(o: unknown, prefix = ""): Record<string, string> {
  if (typeof o === "string") return { [prefix]: o };
  if (Array.isArray(o)) return Object.assign({}, ...o.map((v, i) => flatten(v, `${prefix}[${i}]`)));
  if (o && typeof o === "object") return Object.assign({}, ...Object.entries(o).map(([k, v]) => flatten(v, prefix ? `${prefix}.${k}` : k)));
  return {};
}

describe("i18n (CI check for missing keys)", () => {
  const pt = flatten(ptBR);
  const e = flatten(en);

  it("pt-BR and en have exactly the same keys", () => {
    expect(Object.keys(e).sort()).toEqual(Object.keys(pt).sort());
  });

  it("no empty translations", () => {
    for (const [k, v] of Object.entries({ ...pt })) expect(v.trim(), `pt-BR ${k}`).not.toBe("");
    for (const [k, v] of Object.entries({ ...e })) expect(v.trim(), `en ${k}`).not.toBe("");
  });

  it("placeholders match across languages", () => {
    const ph = (s: string) => (s.match(/\{\w+\}/g) ?? []).sort().join(",");
    for (const k of Object.keys(pt)) expect(ph(e[k]!), k).toBe(ph(pt[k]!));
  });

  it("every grantable permission and plan has a label", () => {
    for (const p of GRANTABLE_PERMISSIONS) expect(ptBR.admin.users.grantNames[p]).toBeTruthy();
    for (const k of PLAN_KEYS) expect(en.plan.names[k]).toBeTruthy();
  });

  it("interpolates", () => {
    expect(fmt(en.dashboard.favorites.usage, { used: 1, max: 2 })).toBe("Favorite assets: 1 of 2");
  });
});
