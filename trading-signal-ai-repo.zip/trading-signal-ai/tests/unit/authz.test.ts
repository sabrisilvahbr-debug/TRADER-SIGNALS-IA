import { describe, it, expect } from "vitest";
import { can, canAccessAdmin, canManageTarget } from "@/lib/authz/permissions";
import { GRANTABLE_PERMISSIONS } from "@/lib/authz/types";
import { ctx, IDS } from "./helpers";

describe("permissions", () => {
  it("OWNER can do everything, including roles.manage", () => {
    const o = ctx("owner", IDS.owner);
    expect(canAccessAdmin(o)).toBe(true);
    for (const p of [...GRANTABLE_PERMISSIONS, "roles.manage" as const]) expect(can(o, p)).toBe(true);
  });

  it("USER never accesses admin and has no permission, even with grants in the object", () => {
    const u = ctx("user", IDS.user, ["users.read", "users.suspend"]);
    expect(canAccessAdmin(u)).toBe(false);
    expect(can(u, "users.read")).toBe(false);
  });

  it("ADMIN only has the explicitly granted permissions", () => {
    const a = ctx("admin", IDS.admin, ["users.read"]);
    expect(canAccessAdmin(a)).toBe(true);
    expect(can(a, "users.read")).toBe(true);
    expect(can(a, "users.suspend")).toBe(false);
    expect(can(a, "engine.pause")).toBe(false);
  });

  it("ADMIN can never hold roles.manage", () => {
    const a = ctx("admin", IDS.admin, [...GRANTABLE_PERMISSIONS]);
    expect(can(a, "roles.manage")).toBe(false);
  });

  it("a suspended OWNER/ADMIN loses all access", () => {
    expect(canAccessAdmin(ctx("owner", IDS.owner, [], "suspended"))).toBe(false);
    expect(can(ctx("admin", IDS.admin, ["users.read"], "suspended"), "users.read")).toBe(false);
  });
});

describe("canManageTarget", () => {
  const owner = ctx("owner", IDS.owner);
  const admin = ctx("admin", IDS.admin, ["users.suspend"]);
  it("nobody manages the OWNER or themselves", () => {
    expect(canManageTarget(owner, { id: IDS.owner, role: "owner" })).toBe(false);
    expect(canManageTarget(admin, { id: IDS.owner, role: "owner" })).toBe(false);
    expect(canManageTarget(admin, { id: IDS.admin, role: "admin" })).toBe(false);
  });
  it("OWNER manages admins and users", () => {
    expect(canManageTarget(owner, { id: IDS.admin, role: "admin" })).toBe(true);
    expect(canManageTarget(owner, { id: IDS.user, role: "user" })).toBe(true);
  });
  it("ADMIN manages only regular users", () => {
    expect(canManageTarget(admin, { id: IDS.user, role: "user" })).toBe(true);
    expect(canManageTarget(admin, { id: IDS.admin2, role: "admin" })).toBe(false);
  });
});
