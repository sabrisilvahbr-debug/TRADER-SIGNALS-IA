import { describe, it, expect } from "vitest";
import { handleUserAdminAction } from "@/server/admin/user-actions";
import { ctx, deps, FakeUserRepo, IDS } from "./helpers";

const suspend = { action: "suspend", confirm: true };

function run(caller: ReturnType<typeof ctx> | null, target: string, body: unknown, opts: { limit?: number } = {}) {
  const d = deps(caller, opts);
  const repo = new FakeUserRepo();
  return { d, repo, result: handleUserAdminAction({ ...d, repo }, target, body) };
}

describe("admin API: authentication and authorization (works without any UI)", () => {
  it("401 without a session, and nothing is changed", async () => {
    const { repo, result } = run(null, IDS.user, suspend);
    expect((await result).status).toBe(401);
    expect(repo.calls).toEqual([]);
  });

  it("403 for a regular USER, audited as denied, nothing changed", async () => {
    const { d, repo, result } = run(ctx("user", IDS.user), IDS.user2, suspend);
    expect((await result).status).toBe(403);
    expect(repo.calls).toEqual([]);
    expect(d.audit.entries[0]).toMatchObject({ result: "denied", actorId: IDS.user, action: "admin.api_access" });
  });

  it("403 for a USER even with a malformed body (no validation oracle)", async () => {
    const { result } = run(ctx("user", IDS.user), "not-a-uuid", { junk: true });
    expect((await result).status).toBe(403);
  });

  it("a suspended OWNER is denied", async () => {
    const { result } = run(ctx("owner", IDS.owner, [], "suspended"), IDS.user, suspend);
    expect((await result).status).toBe(403);
  });

  it("ADMIN without users.suspend is denied", async () => {
    const { d, repo, result } = run(ctx("admin", IDS.admin, ["users.read"]), IDS.user, suspend);
    expect((await result).status).toBe(403);
    expect(repo.calls).toEqual([]);
    expect(d.audit.entries[0]).toMatchObject({ result: "denied", action: "user.suspend" });
  });

  it("ADMIN with users.suspend can suspend a regular user (audited)", async () => {
    const { d, repo, result } = run(ctx("admin", IDS.admin, ["users.suspend"]), IDS.user, suspend);
    expect((await result).status).toBe(200);
    expect(repo.calls).toEqual([`status:${IDS.user}:suspended`]);
    expect(d.audit.entries[0]).toMatchObject({ result: "success", action: "user.suspend", actorId: IDS.admin, targetId: IDS.user });
  });

  it("ADMIN cannot suspend another ADMIN, the OWNER or themselves", async () => {
    for (const target of [IDS.admin2, IDS.owner, IDS.admin]) {
      const { repo, result } = run(ctx("admin", IDS.admin, ["users.suspend"]), target, suspend);
      expect((await result).status).toBe(403);
      expect(repo.calls).toEqual([]);
    }
  });

  it("nobody can suspend the OWNER, not even the OWNER", async () => {
    const { repo, result } = run(ctx("owner", IDS.owner), IDS.owner, suspend);
    expect((await result).status).toBe(403);
    expect(repo.calls).toEqual([]);
  });

  it("destructive actions require explicit confirmation", async () => {
    const { repo, result } = run(ctx("owner", IDS.owner), IDS.user, { action: "suspend" });
    expect((await result).status).toBe(400);
    expect(repo.calls).toEqual([]);
    const r2 = run(ctx("owner", IDS.owner), IDS.user, { action: "suspend", confirm: false });
    expect((await r2.result).status).toBe(400);
  });
});

describe("admin API: role and grant changes (OWNER only)", () => {
  it("a user cannot change their own role", async () => {
    const { repo, result } = run(ctx("user", IDS.user), IDS.user, { action: "set_role", role: "admin", confirm: true });
    expect((await result).status).toBe(403);
    expect(repo.calls).toEqual([]);
  });

  it("an ADMIN, even with every grant, cannot change roles or grants", async () => {
    const all = ctx("admin", IDS.admin, ["users.read", "users.suspend", "billing.read", "plans.read", "engine.read", "engine.pause", "audit.read"]);
    const a = run(all, IDS.user, { action: "set_role", role: "admin", confirm: true });
    expect((await a.result).status).toBe(403);
    const b = run(all, IDS.admin2, { action: "set_grants", grants: ["users.read"], confirm: true });
    expect((await b.result).status).toBe(403);
    expect(a.repo.calls.concat(b.repo.calls)).toEqual([]);
  });

  it("cannot assign owner through the API (schema rejects it)", async () => {
    const { repo, result } = run(ctx("owner", IDS.owner), IDS.user, { action: "set_role", role: "owner", confirm: true });
    expect((await result).status).toBe(400);
    expect(repo.calls).toEqual([]);
  });

  it("OWNER promotes a user to admin and the change is audited with previous/new role", async () => {
    const { d, repo, result } = run(ctx("owner", IDS.owner), IDS.user, { action: "set_role", role: "admin", confirm: true });
    expect((await result).status).toBe(200);
    expect(repo.calls).toEqual([`role:${IDS.user}:admin`]);
    expect(d.audit.entries[0]).toMatchObject({
      result: "success",
      action: "user.set_role",
      metadata: { previousRole: "user", newRole: "admin" },
    });
  });

  it("grants can only be set on admins, with known permissions", async () => {
    const ok = run(ctx("owner", IDS.owner), IDS.admin, { action: "set_grants", grants: ["users.read", "audit.read"], confirm: true });
    expect((await ok.result).status).toBe(200);
    expect(ok.repo.calls).toEqual([`grants:${IDS.admin}:users.read+audit.read:by:${IDS.owner}`]);

    const onUser = run(ctx("owner", IDS.owner), IDS.user, { action: "set_grants", grants: ["users.read"], confirm: true });
    expect((await onUser.result).status).toBe(409);

    const bogus = run(ctx("owner", IDS.owner), IDS.admin, { action: "set_grants", grants: ["roles.manage"], confirm: true });
    expect((await bogus.result).status).toBe(400);
  });
});

describe("admin API: robustness", () => {
  it("404 for an unknown target and 400 for a malformed id", async () => {
    expect((await run(ctx("owner", IDS.owner), "00000000-0000-4000-8000-0000000000ff", suspend).result).status).toBe(404);
    expect((await run(ctx("owner", IDS.owner), "../etc/passwd", suspend).result).status).toBe(400);
  });

  it("rate limits repeated calls with Retry-After", async () => {
    const d = deps(ctx("owner", IDS.owner), { limit: 2 });
    const repo = new FakeUserRepo();
    const call = () => handleUserAdminAction({ ...d, repo }, IDS.user, suspend);
    expect((await call()).status).toBe(200);
    expect((await call()).status).toBe(200);
    const third = await call();
    expect(third.status).toBe(429);
    expect(third.headers?.["Retry-After"]).toBeDefined();
  });

  it("returns a generic 500 (no internals) and audits an error when the database fails", async () => {
    const d = deps(ctx("owner", IDS.owner));
    const repo = new FakeUserRepo();
    repo.fail = true;
    const r = await handleUserAdminAction({ ...d, repo }, IDS.user, suspend);
    expect(r).toEqual({ status: 500, body: { error: "internal_error" } });
    expect(d.audit.entries.at(-1)).toMatchObject({ result: "error" });
  });

  it("does not hide a failed audit write after a sensitive change", async () => {
    const d = deps(ctx("owner", IDS.owner));
    d.audit.fail = true;
    const repo = new FakeUserRepo();
    const r = await handleUserAdminAction({ ...d, repo }, IDS.user, suspend);
    expect(r.status).toBe(500);
    expect(r.body).toEqual({ error: "audit_failed", applied: true });
  });

  it("audit metadata carries no credentials or e-mails", async () => {
    const { d, result } = run(ctx("owner", IDS.owner), IDS.user, suspend);
    await result;
    expect(JSON.stringify(d.audit.entries)).not.toMatch(/@|password|token|secret|key/i);
  });
});
