import type { AuthContext, GrantablePermission, Role } from "@/lib/authz/types";
import type { PlanCatalog } from "@/lib/authz/plans";
import type { AuditEntry, AuditWriter, EngineRepo, TargetProfile, UserAdminRepo } from "@/server/admin/types";
import { createRateLimiter } from "@/lib/rate-limit";

export const IDS = {
  owner: "00000000-0000-4000-8000-000000000001",
  admin: "00000000-0000-4000-8000-000000000002",
  admin2: "00000000-0000-4000-8000-000000000003",
  user: "00000000-0000-4000-8000-000000000004",
  user2: "00000000-0000-4000-8000-000000000005",
};

export function ctx(role: Role, id: string, grants: GrantablePermission[] = [], status: "active" | "suspended" = "active"): AuthContext {
  return { userId: id, email: `${role}@example.com`, role, status, grants };
}

export const PLANS: PlanCatalog = {
  free: { key: "free", name: "Free", maxAssets: 1, timeframes: ["1h", "4h"], historyDays: 7, features: ["signal_feed_limited"], published: true, priceMonthlyCents: null, priceYearlyCents: null, currency: null },
  pro: { key: "pro", name: "Pro", maxAssets: 2, timeframes: ["15m", "1h", "4h"], historyDays: 30, features: ["signal_feed", "stats"], published: false, priceMonthlyCents: null, priceYearlyCents: null, currency: null },
  premium: { key: "premium", name: "Premium", maxAssets: 10, timeframes: ["1m", "5m", "15m", "1h", "4h"], historyDays: 365, features: ["signal_feed", "stats", "advanced_analytics"], published: false, priceMonthlyCents: null, priceYearlyCents: null, currency: null },
};

export class FakeAudit implements AuditWriter {
  entries: AuditEntry[] = [];
  fail = false;
  async write(e: AuditEntry) {
    if (this.fail) throw new Error("audit down");
    this.entries.push(e);
  }
}

export class FakeUserRepo implements UserAdminRepo {
  calls: string[] = [];
  fail = false;
  profiles = new Map<string, TargetProfile>([
    [IDS.owner, { id: IDS.owner, role: "owner", status: "active" }],
    [IDS.admin, { id: IDS.admin, role: "admin", status: "active" }],
    [IDS.admin2, { id: IDS.admin2, role: "admin", status: "active" }],
    [IDS.user, { id: IDS.user, role: "user", status: "active" }],
    [IDS.user2, { id: IDS.user2, role: "user", status: "active" }],
  ]);
  async getProfile(id: string) {
    return this.profiles.get(id) ?? null;
  }
  async setStatus(id: string, status: "active" | "suspended") {
    if (this.fail) throw new Error("db down");
    this.calls.push(`status:${id}:${status}`);
  }
  async setRole(id: string, role: "admin" | "user") {
    if (this.fail) throw new Error("db down");
    this.calls.push(`role:${id}:${role}`);
  }
  async setGrants(id: string, grants: GrantablePermission[], by: string) {
    if (this.fail) throw new Error("db down");
    this.calls.push(`grants:${id}:${grants.join("+")}:by:${by}`);
  }
}

export class FakeEngineRepo implements EngineRepo {
  calls: string[] = [];
  async setSignalsPaused(paused: boolean, by: string) {
    this.calls.push(`paused:${paused}:by:${by}`);
  }
}

export function deps(caller: AuthContext | null, over: { limit?: number } = {}) {
  const audit = new FakeAudit();
  return {
    audit,
    limiter: createRateLimiter({ limit: over.limit ?? 100, windowMs: 60_000 }),
    getAuthContext: async () => caller,
    log: () => undefined,
  };
}
