import { describe, it, expect } from "vitest";
import { allowsTimeframe, assetLimitReached, resolveEffectiveAccess, RESTRICTED_PLAN, type SubscriptionLite } from "@/lib/authz/plans";
import { PLANS } from "./helpers";

const now = new Date("2026-10-20T12:00:00Z");
const day = 86_400_000;
const sub = (over: Partial<SubscriptionLite>): SubscriptionLite => ({
  planKey: "pro",
  status: "active",
  currentPeriodEnd: new Date(now.getTime() + 10 * day),
  cancelAtPeriodEnd: false,
  ...over,
});
const resolve = (role: "owner" | "admin" | "user", subscription: SubscriptionLite | null) =>
  resolveEffectiveAccess({ role, subscription, plans: PLANS, now });

describe("effective access", () => {
  it("OWNER gets PREMIUM limits, is billing-exempt and needs no subscription", () => {
    const a = resolve("owner", null);
    expect(a).toMatchObject({ billingExempt: true, label: "OWNER", reason: "owner_exemption" });
    expect(a.plan.key).toBe("premium");
  });

  it("OWNER keeps access whatever Stripe says (canceled/unpaid)", () => {
    for (const status of ["canceled", "unpaid", "past_due", "incomplete"] as const) {
      const a = resolve("owner", sub({ status, currentPeriodEnd: new Date(now.getTime() - 100 * day) }));
      expect(a.plan.key).toBe("premium");
      expect(a.billingExempt).toBe(true);
    }
  });

  it("a regular customer with no subscription gets FREE, not paid features", () => {
    const a = resolve("user", null);
    expect(a.label).toBe("free");
    expect(a.billingExempt).toBe(false);
    expect(a.plan.features).not.toContain("stats");
  });

  it("ADMIN role does not upgrade the commercial plan", () => {
    expect(resolve("admin", null).label).toBe("free");
  });

  it("active and trialing grant the paid plan", () => {
    expect(resolve("user", sub({ status: "active" })).label).toBe("pro");
    expect(resolve("user", sub({ status: "trialing" })).reason).toBe("subscription_trialing");
  });

  it("scheduled cancellation keeps access until the period ends, then drops", () => {
    expect(resolve("user", sub({ cancelAtPeriodEnd: true })).label).toBe("pro");
    const over = resolve("user", sub({ cancelAtPeriodEnd: true, currentPeriodEnd: new Date(now.getTime() - 1000) }));
    expect(over).toMatchObject({ label: "free", reason: "cancel_scheduled_period_over" });
  });

  it("past_due keeps access only inside the grace window", () => {
    const inGrace = sub({ status: "past_due", currentPeriodEnd: new Date(now.getTime() - 1 * day) });
    const expired = sub({ status: "past_due", currentPeriodEnd: new Date(now.getTime() - 5 * day) });
    expect(resolve("user", inGrace)).toMatchObject({ label: "pro", reason: "past_due_in_grace" });
    expect(resolve("user", expired)).toMatchObject({ label: "free", reason: "past_due_grace_expired" });
    expect(resolve("user", sub({ status: "past_due", currentPeriodEnd: null })).label).toBe("free");
  });

  it.each(["incomplete", "incomplete_expired", "unpaid", "paused", "canceled"] as const)("%s does not grant paid access", (status) => {
    expect(resolve("user", sub({ status })).label).toBe("free");
  });

  it("fails closed when the plan catalog is unavailable", () => {
    const a = resolveEffectiveAccess({ role: "user", subscription: null, plans: {}, now });
    expect(a.plan).toEqual(RESTRICTED_PLAN);
    expect(assetLimitReached(a, 0)).toBe(true);
    expect(resolveEffectiveAccess({ role: "user", subscription: sub({}), plans: { free: PLANS.free }, now }).reason).toBe("plan_unavailable");
  });

  it("applies plan limits", () => {
    const free = resolve("user", null);
    expect(assetLimitReached(free, 0)).toBe(false);
    expect(assetLimitReached(free, 1)).toBe(true);
    expect(allowsTimeframe(free, "1m")).toBe(false);
    expect(allowsTimeframe(resolve("owner", null), "1m")).toBe(true);
  });
});
