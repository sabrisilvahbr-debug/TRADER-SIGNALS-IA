import { describe, it, expect } from "vitest";
import { handleEnginePause } from "@/server/admin/engine-actions";
import { handleCheckout } from "@/server/billing/checkout";
import { decideCheckout } from "@/lib/billing/checkout-guard";
import { addFavorite, removeFavorite, type FavoritesRepo } from "@/server/favorites/service";
import { resolveEffectiveAccess } from "@/lib/authz/plans";
import { createRateLimiter } from "@/lib/rate-limit";
import { isSameOrigin, safeNextPath } from "@/lib/safe-redirect";
import { ctx, deps, FakeEngineRepo, IDS, PLANS } from "./helpers";

describe("checkout is never started for the OWNER", () => {
  it("guard decisions", () => {
    expect(decideCheckout(ctx("owner", IDS.owner))).toEqual({ allowed: false, status: 409, code: "owner_exempt" });
    expect(decideCheckout(ctx("user", IDS.user))).toEqual({ allowed: true });
    expect(decideCheckout(ctx("user", IDS.user, [], "suspended"))).toMatchObject({ allowed: false, status: 403 });
  });

  it("OWNER gets 409 and the decision is audited (no Stripe involved)", async () => {
    const d = deps(ctx("owner", IDS.owner));
    const r = await handleCheckout(d);
    expect(r).toEqual({ status: 409, body: { error: "owner_exempt" } });
    expect(d.audit.entries[0]).toMatchObject({ action: "billing.checkout_skipped_owner_exempt" });
  });

  it("unauthenticated gets 401; regular users get an honest 501 until billing is wired", async () => {
    expect((await handleCheckout(deps(null))).status).toBe(401);
    expect((await handleCheckout(deps(ctx("user", IDS.user)))).status).toBe(501);
  });
});

describe("engine pause", () => {
  const body = { paused: true, confirm: true };
  it("denies users and admins without engine.pause; audits the denial", async () => {
    for (const caller of [ctx("user", IDS.user), ctx("admin", IDS.admin, ["engine.read"])]) {
      const d = deps(caller);
      const repo = new FakeEngineRepo();
      expect((await handleEnginePause({ ...d, repo }, body)).status).toBe(403);
      expect(repo.calls).toEqual([]);
      expect(d.audit.entries[0]).toMatchObject({ result: "denied", action: "engine.pause" });
    }
  });
  it("allows an admin with engine.pause and the OWNER; requires confirmation", async () => {
    const d = deps(ctx("admin", IDS.admin, ["engine.pause"]));
    const repo = new FakeEngineRepo();
    expect((await handleEnginePause({ ...d, repo }, body)).status).toBe(200);
    expect(repo.calls).toEqual([`paused:true:by:${IDS.admin}`]);
    expect(d.audit.entries[0]).toMatchObject({ action: "engine.pause", result: "success" });
    expect((await handleEnginePause({ ...d, repo }, { paused: true })).status).toBe(400);
    expect((await handleEnginePause({ ...deps(null), repo }, body)).status).toBe(401);
    const o = deps(ctx("owner", IDS.owner));
    expect((await handleEnginePause({ ...o, repo }, { paused: false, confirm: true })).status).toBe(200);
    expect(o.audit.entries[0]).toMatchObject({ action: "engine.resume" });
  });
});

class MemFavs implements FavoritesRepo {
  data = new Map<string, Set<string>>();
  async list(u: string) { return [...(this.data.get(u) ?? [])]; }
  async add(u: string, s: string) { (this.data.get(u) ?? this.data.set(u, new Set()).get(u)!).add(s); }
  async remove(u: string, s: string) { this.data.get(u)?.delete(s); }
}

describe("favorites + plan limits (server-side)", () => {
  const free = resolveEffectiveAccess({ role: "user", subscription: null, plans: PLANS });
  const owner = resolveEffectiveAccess({ role: "owner", subscription: null, plans: PLANS });
  const me = { userId: IDS.user, status: "active" as const };

  it("enforces the FREE limit and is idempotent", async () => {
    const repo = new MemFavs();
    expect(await addFavorite(repo, me, free, "BTCUSDT")).toEqual({ ok: true });
    expect(await addFavorite(repo, me, free, "BTCUSDT")).toEqual({ ok: true });
    expect(await addFavorite(repo, me, free, "ETHUSDT")).toEqual({ ok: false, code: "limit_reached" });
    expect(await repo.list(IDS.user)).toEqual(["BTCUSDT"]);
  });

  it("OWNER gets the PREMIUM limit without a subscription", async () => {
    const repo = new MemFavs();
    expect(await addFavorite(repo, me, owner, "BTCUSDT")).toEqual({ ok: true });
    expect(await addFavorite(repo, me, owner, "ETHUSDT")).toEqual({ ok: true });
  });

  it("rejects unsupported symbols and suspended accounts", async () => {
    const repo = new MemFavs();
    expect(await addFavorite(repo, me, owner, "DOGEUSDT")).toEqual({ ok: false, code: "invalid_symbol" });
    expect(await addFavorite(repo, me, owner, { $ne: 1 })).toEqual({ ok: false, code: "invalid_symbol" });
    expect(await addFavorite(repo, { ...me, status: "suspended" }, owner, "BTCUSDT")).toEqual({ ok: false, code: "suspended" });
  });

  it("only ever touches the caller's own rows", async () => {
    const repo = new MemFavs();
    await addFavorite(repo, { userId: IDS.user2, status: "active" }, free, "BTCUSDT");
    await removeFavorite(repo, me, "BTCUSDT");
    expect(await repo.list(IDS.user2)).toEqual(["BTCUSDT"]);
  });
});

describe("rate limiter / redirects", () => {
  it("slides the window", () => {
    let t = 0;
    const rl = createRateLimiter({ limit: 2, windowMs: 1000, now: () => t });
    expect(rl.check("k").ok).toBe(true);
    expect(rl.check("k").ok).toBe(true);
    expect(rl.check("k").ok).toBe(false);
    expect(rl.check("other").ok).toBe(true);
    t = 1500;
    expect(rl.check("k").ok).toBe(true);
  });

  it("blocks open redirects", () => {
    expect(safeNextPath("/dashboard/favorites")).toBe("/dashboard/favorites");
    for (const bad of ["https://evil.com", "//evil.com", "/\\evil.com", "javascript:alert(1)", "", null, undefined]) {
      expect(safeNextPath(bad as string | null | undefined)).toBe("/dashboard");
    }
  });

  it("checks origin", () => {
    expect(isSameOrigin("https://app.example.com", "https://app.example.com/api/x")).toBe(true);
    expect(isSameOrigin("https://evil.com", "https://app.example.com/api/x")).toBe(false);
    expect(isSameOrigin("not a url", "https://app.example.com/api/x")).toBe(false);
    expect(isSameOrigin(null, "https://app.example.com/api/x")).toBe(true);
  });
});
