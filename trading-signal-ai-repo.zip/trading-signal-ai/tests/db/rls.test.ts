import { describe, it, expect, beforeAll } from "vitest";
import type { PGlite } from "@electric-sql/pglite";
import { as, createUser, roleOf, setupDb } from "./helpers";

const DENIED = { code: "42501" };

let db: PGlite;
let alice: string;
let bob: string;
let owner: string;

beforeAll(async () => {
  db = await setupDb();
  alice = await createUser(db, "alice@example.com");
  bob = await createUser(db, "bob@example.com");
  owner = await createUser(db, "owner@example.com");
  // Service-side seeding (what the backend would do).
  await as(db, "service_role", null, async () => {
    await db.query("insert into public.user_favorites (user_id, symbol) values ($1,'BTCUSDT'), ($2,'ETHUSDT')", [alice, bob]);
    await db.query(
      "insert into public.subscriptions (user_id, stripe_customer_id, plan_key, status) values ($1,'cus_a','pro','active'), ($2,'cus_b','premium','active')",
      [alice, bob],
    );
  });
  await db.query("select public.bootstrap_owner('owner@example.com')");
});

describe("signup trigger", () => {
  it("creates a profile with role=user/status=active", async () => {
    expect(await roleOf(db, alice)).toEqual({ role: "user", status: "active" });
  });

  it("ignores role/status injected through user-editable metadata", async () => {
    const evil = await createUser(db, "evil@example.com", { meta: { role: "owner", status: "active", locale: "en" } });
    expect(await roleOf(db, evil)).toEqual({ role: "user", status: "active" });
    const r = await db.query<{ locale: string }>("select locale from public.profiles where id=$1", [evil]);
    expect(r.rows[0]!.locale).toBe("en");
  });

  it("falls back to pt-BR for an unsupported locale", async () => {
    const id = await createUser(db, "x@example.com", { meta: { locale: "xx" } });
    const r = await db.query<{ locale: string }>("select locale from public.profiles where id=$1", [id]);
    expect(r.rows[0]!.locale).toBe("pt-BR");
  });
});

describe("user isolation (RLS)", () => {
  it("a user sees only their own profile", async () => {
    const rows = await as(db, "authenticated", alice, async () => (await db.query<{ id: string }>("select id from public.profiles")).rows);
    expect(rows.map((r) => r.id)).toEqual([alice]);
  });

  it("a user sees only their own favorites and subscription", async () => {
    await as(db, "authenticated", alice, async () => {
      const f = await db.query<{ symbol: string }>("select symbol from public.user_favorites");
      const s = await db.query<{ plan_key: string }>("select plan_key from public.subscriptions");
      expect(f.rows.map((r) => r.symbol)).toEqual(["BTCUSDT"]);
      expect(s.rows.map((r) => r.plan_key)).toEqual(["pro"]);
    });
  });

  it("changing the id in a query does not expose another user's data", async () => {
    const r = await as(db, "authenticated", alice, () => db.query("select * from public.subscriptions where user_id = $1", [bob]));
    expect(r.rows).toHaveLength(0);
  });

  it("a user cannot update another user's profile", async () => {
    const r = await as(db, "authenticated", alice, () =>
      db.query("update public.profiles set display_name='hacked' where id = $1 returning id", [bob]),
    );
    expect(r.rows).toHaveLength(0);
  });

  it("anon sees nothing", async () => {
    await expect(as(db, "anon", null, () => db.query("select * from public.profiles"))).rejects.toMatchObject(DENIED);
  });
});

describe("privilege escalation attempts by an authenticated user", () => {
  it("can update harmless columns of their own profile", async () => {
    await as(db, "authenticated", alice, () => db.query("update public.profiles set display_name='Alice', locale='en' where id=$1", [alice]));
    const r = await db.query<{ display_name: string }>("select display_name from public.profiles where id=$1", [alice]);
    expect(r.rows[0]!.display_name).toBe("Alice");
  });

  it.each(["role = 'owner'", "role = 'admin'", "status = 'suspended'", "email = 'x@y.z'"])("cannot set %s on own profile", async (assignment) => {
    await expect(
      as(db, "authenticated", alice, () => db.query(`update public.profiles set ${assignment} where id=$1`, [alice])),
    ).rejects.toMatchObject(DENIED);
    expect(await roleOf(db, alice)).toEqual({ role: "user", status: "active" });
  });

  it("cannot create or edit subscriptions", async () => {
    await expect(
      as(db, "authenticated", alice, () =>
        db.query("insert into public.subscriptions (user_id, stripe_customer_id, plan_key, status) values ($1,'c','premium','active')", [alice]),
      ),
    ).rejects.toMatchObject(DENIED);
    await expect(
      as(db, "authenticated", alice, () => db.query("update public.subscriptions set plan_key='premium' where user_id=$1", [alice])),
    ).rejects.toMatchObject(DENIED);
  });

  it("cannot write favorites directly (plan limits are enforced by the server)", async () => {
    await expect(
      as(db, "authenticated", alice, () => db.query("insert into public.user_favorites (user_id, symbol) values ($1,'ETHUSDT')", [alice])),
    ).rejects.toMatchObject(DENIED);
  });

  it.each(["admin_grants", "audit_logs", "system_flags", "plans"])("cannot read or write %s", async (table) => {
    await expect(as(db, "authenticated", alice, () => db.query(`select * from public.${table}`))).rejects.toMatchObject(DENIED);
    await expect(as(db, "authenticated", alice, () => db.query(`delete from public.${table}`))).rejects.toMatchObject(DENIED);
  });

  it("cannot grant themselves admin permissions", async () => {
    await expect(
      as(db, "authenticated", alice, () => db.query("insert into public.admin_grants (user_id, permission) values ($1,'users.read')", [alice])),
    ).rejects.toMatchObject(DENIED);
  });

  it("cannot call bootstrap_owner", async () => {
    await expect(as(db, "authenticated", alice, () => db.query("select public.bootstrap_owner('alice@example.com')"))).rejects.toMatchObject(DENIED);
    await expect(as(db, "anon", null, () => db.query("select public.bootstrap_owner('alice@example.com')"))).rejects.toMatchObject(DENIED);
    expect((await roleOf(db, alice)).role).toBe("user");
  });
});

describe("owner bootstrap", () => {
  it("assigned the owner role to the verified account", async () => {
    expect((await roleOf(db, owner)).role).toBe("owner");
  });

  it("is idempotent", async () => {
    const r = await as(db, "service_role", null, () => db.query<{ bootstrap_owner: string }>("select public.bootstrap_owner('OWNER@example.com ')"));
    expect(r.rows[0]!.bootstrap_owner).toBe("already_owner");
  });

  it("refuses an unconfirmed account and does not grant privileges", async () => {
    const db2 = await setupDb();
    const u = await createUser(db2, "boss@example.com", { confirmed: false });
    const r = await db2.query<{ bootstrap_owner: string }>("select public.bootstrap_owner('boss@example.com')");
    expect(r.rows[0]!.bootstrap_owner).toBe("email_not_confirmed");
    expect((await roleOf(db2, u)).role).toBe("user");
  });

  it("reports an unknown e-mail and invalid input without side effects", async () => {
    const a = await db.query<{ bootstrap_owner: string }>("select public.bootstrap_owner('nobody@example.com')");
    const b = await db.query<{ bootstrap_owner: string }>("select public.bootstrap_owner('')");
    expect(a.rows[0]!.bootstrap_owner).toBe("user_not_found");
    expect(b.rows[0]!.bootstrap_owner).toBe("invalid_email");
  });

  it("never assigns a second owner", async () => {
    const r = await db.query<{ bootstrap_owner: string }>("select public.bootstrap_owner('bob@example.com')");
    expect(r.rows[0]!.bootstrap_owner).toBe("owner_already_assigned_to_other_user");
    expect((await roleOf(db, bob)).role).toBe("user");
  });

  it("writes audit entries for success and denial", async () => {
    const r = await db.query<{ result: string }>("select result from public.audit_logs where action='owner.bootstrap' order by id");
    expect(r.rows.map((x) => x.result)).toEqual(["success", "denied"]);
  });
});

describe("OWNER protection against the backend itself (billing webhooks use service_role)", () => {
  it("service_role cannot demote the owner", async () => {
    await expect(
      as(db, "service_role", null, () => db.query("update public.profiles set role='user' where id=$1", [owner])),
    ).rejects.toMatchObject(DENIED);
  });

  it("service_role cannot suspend the owner", async () => {
    await expect(
      as(db, "service_role", null, () => db.query("update public.profiles set status='suspended' where id=$1", [owner])),
    ).rejects.toMatchObject(DENIED);
  });

  it("service_role cannot promote someone to owner", async () => {
    await expect(
      as(db, "service_role", null, () => db.query("update public.profiles set role='owner' where id=$1", [bob])),
    ).rejects.toMatchObject(DENIED);
  });

  it("subscription changes (webhook-style) leave the owner role untouched", async () => {
    await as(db, "service_role", null, async () => {
      await db.query(
        "insert into public.subscriptions (user_id, stripe_customer_id, plan_key, status) values ($1,'cus_o','pro','canceled')",
        [owner],
      );
      await db.query("update public.subscriptions set status='unpaid' where user_id=$1", [owner]);
      await db.query("delete from public.subscriptions where user_id=$1", [owner]);
    });
    expect(await roleOf(db, owner)).toEqual({ role: "owner", status: "active" });
  });

  it("service_role can manage regular users (suspend / promote to admin)", async () => {
    await as(db, "service_role", null, () => db.query("update public.profiles set status='suspended' where id=$1", [bob]));
    expect(await roleOf(db, bob)).toEqual({ role: "user", status: "suspended" });
    await as(db, "service_role", null, () => db.query("update public.profiles set status='active', role='admin' where id=$1", [bob]));
    expect(await roleOf(db, bob)).toEqual({ role: "admin", status: "active" });
  });
});

describe("audit log is append-only", () => {
  it("rejects update, delete and truncate even for service_role", async () => {
    await as(db, "service_role", null, async () => {
      await db.query("insert into public.audit_logs (action, result) values ('test.event','success')");
      await expect(db.query("update public.audit_logs set result='error'")).rejects.toMatchObject(DENIED);
      await expect(db.query("delete from public.audit_logs")).rejects.toMatchObject(DENIED);
      await expect(db.query("truncate public.audit_logs")).rejects.toMatchObject(DENIED);
    });
  });
});

describe("single owner constraint", () => {
  it("is enforced by a unique index even for the migration role", async () => {
    await expect(db.query("update public.profiles set role='owner' where id=$1", [alice])).rejects.toBeDefined();
  });
});
