import { PGlite } from "@electric-sql/pglite";
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";

const root = join(__dirname, "..", "..");

export async function setupDb(): Promise<PGlite> {
  const db = new PGlite();
  await db.exec(readFileSync(join(__dirname, "supabase-shim.sql"), "utf8"));
  const dir = join(root, "supabase", "migrations");
  for (const f of readdirSync(dir).filter((n) => n.endsWith(".sql")).sort()) {
    await db.exec(readFileSync(join(dir, f), "utf8"));
  }
  return db;
}

type Role = "anon" | "authenticated" | "service_role";

/** Runs `fn` with the session switched to a Supabase role (and JWT subject). */
export async function as<T>(db: PGlite, role: Role, userId: string | null, fn: () => Promise<T>): Promise<T> {
  await db.query("select set_config('request.jwt.claim.sub', $1, false)", [userId ?? ""]);
  await db.exec(`set role ${role}`);
  try {
    return await fn();
  } finally {
    await db.exec("reset role");
  }
}

export async function createUser(
  db: PGlite,
  email: string,
  opts: { confirmed?: boolean; meta?: Record<string, unknown> } = {},
): Promise<string> {
  const { confirmed = true, meta = {} } = opts;
  const r = await db.query<{ id: string }>(
    `insert into auth.users (email, email_confirmed_at, raw_user_meta_data)
     values ($1, ${confirmed ? "now()" : "null"}, $2::jsonb) returning id`,
    [email, JSON.stringify(meta)],
  );
  return r.rows[0]!.id;
}

export async function roleOf(db: PGlite, id: string): Promise<{ role: string; status: string }> {
  const r = await db.query<{ role: string; status: string }>("select role::text, status::text from public.profiles where id = $1", [id]);
  return r.rows[0]!;
}
