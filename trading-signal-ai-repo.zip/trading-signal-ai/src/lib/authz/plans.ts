import type { Role } from "./types";

export const PLAN_KEYS = ["free", "pro", "premium"] as const;
export type PlanKey = (typeof PLAN_KEYS)[number];

export const SUPPORTED_ASSETS = ["BTCUSDT", "ETHUSDT"] as const;
export const SUPPORTED_TIMEFRAMES = ["1m", "5m", "15m", "1h", "4h"] as const;

export interface PlanDefinition {
  key: PlanKey;
  name: string;
  maxAssets: number;
  timeframes: string[];
  historyDays: number;
  features: string[];
  published: boolean;
  priceMonthlyCents: number | null;
  priceYearlyCents: number | null;
  currency: string | null;
}
export type PlanCatalog = Record<PlanKey, PlanDefinition>;

/**
 * Used ONLY when the catalog cannot be loaded from the database. Fails closed:
 * no assets, no timeframes, no features.
 */
export const RESTRICTED_PLAN: PlanDefinition = {
  key: "free",
  name: "Free",
  maxAssets: 0,
  timeframes: [],
  historyDays: 0,
  features: [],
  published: true,
  priceMonthlyCents: null,
  priceYearlyCents: null,
  currency: null,
};

export const SUBSCRIPTION_STATUSES = [
  "incomplete",
  "incomplete_expired",
  "trialing",
  "active",
  "past_due",
  "canceled",
  "unpaid",
  "paused",
] as const;
export type SubscriptionStatus = (typeof SUBSCRIPTION_STATUSES)[number];

export interface SubscriptionLite {
  planKey: PlanKey;
  status: SubscriptionStatus;
  currentPeriodEnd: Date | null;
  cancelAtPeriodEnd: boolean;
}

/** Explicit commercial policy (kept separate from Stripe's own status). */
export interface AccessPolicy {
  /** Days of paid access kept after the period end while the payment is past_due. */
  pastDueGraceDays: number;
}
export const DEFAULT_ACCESS_POLICY: AccessPolicy = { pastDueGraceDays: 3 };

export type AccessReason =
  | "owner_exemption"
  | "free_default"
  | "subscription_active"
  | "subscription_trialing"
  | "past_due_in_grace"
  | "past_due_grace_expired"
  | "cancel_scheduled_period_over"
  | "subscription_not_paid"
  | "plan_unavailable";

export interface EffectiveAccess {
  role: Role;
  /** OWNER never pays and never needs a Stripe subscription. */
  billingExempt: boolean;
  /** Plan whose limits apply (OWNER receives the PREMIUM definition). */
  plan: PlanDefinition;
  /** What the UI shows as the plan name. */
  label: "OWNER" | PlanKey;
  reason: AccessReason;
}

const DAY_MS = 86_400_000;

export function resolveEffectiveAccess(input: {
  role: Role;
  subscription: SubscriptionLite | null;
  plans: Partial<PlanCatalog>;
  now?: Date;
  policy?: AccessPolicy;
}): EffectiveAccess {
  const { role, subscription, plans } = input;
  const now = input.now ?? new Date();
  const policy = input.policy ?? DEFAULT_ACCESS_POLICY;
  const free = plans.free ?? RESTRICTED_PLAN;

  // The OWNER exemption is decided here, in the backend, and never looks at Stripe.
  if (role === "owner") {
    return {
      role,
      billingExempt: true,
      plan: plans.premium ?? free,
      label: "OWNER",
      reason: "owner_exemption",
    };
  }

  const asFree = (reason: AccessReason): EffectiveAccess => ({
    role,
    billingExempt: false,
    plan: free,
    label: "free",
    reason,
  });
  if (!subscription) return asFree("free_default");

  const paid = plans[subscription.planKey];
  if (!paid) return asFree("plan_unavailable");
  const grant = (reason: AccessReason): EffectiveAccess => ({
    role,
    billingExempt: false,
    plan: paid,
    label: subscription.planKey,
    reason,
  });

  const end = subscription.currentPeriodEnd;
  switch (subscription.status) {
    case "active":
      // cancel_at_period_end is NOT "already ended": access lasts until the period is over.
      if (subscription.cancelAtPeriodEnd && end && now >= end) return asFree("cancel_scheduled_period_over");
      return grant("subscription_active");
    case "trialing":
      return grant("subscription_trialing");
    case "past_due":
      if (end && now.getTime() < end.getTime() + policy.pastDueGraceDays * DAY_MS) return grant("past_due_in_grace");
      return asFree("past_due_grace_expired");
    default:
      // incomplete, incomplete_expired, unpaid, paused, canceled
      return asFree("subscription_not_paid");
  }
}

export function allowsTimeframe(access: EffectiveAccess, tf: string): boolean {
  return access.plan.timeframes.includes(tf);
}

export function assetLimitReached(access: EffectiveAccess, currentCount: number): boolean {
  return currentCount >= access.plan.maxAssets;
}

export function allowsFeature(access: EffectiveAccess, feature: string): boolean {
  return access.plan.features.includes(feature);
}
