export const ROLES = ["owner", "admin", "user"] as const;
export type Role = (typeof ROLES)[number];

export const ACCOUNT_STATUSES = ["active", "suspended"] as const;
export type AccountStatus = (typeof ACCOUNT_STATUSES)[number];

/** Permissions the OWNER can grant to an ADMIN. */
export const GRANTABLE_PERMISSIONS = [
  "users.read",
  "users.suspend",
  "billing.read",
  "plans.read",
  "engine.read",
  "engine.pause",
  "audit.read",
] as const;
export type GrantablePermission = (typeof GRANTABLE_PERMISSIONS)[number];

/** Never grantable: belongs to the OWNER only. */
export type Permission = GrantablePermission | "roles.manage";

/** Identity + privileges of the caller, always loaded server-side from the database. */
export interface AuthContext {
  userId: string;
  email: string;
  role: Role;
  status: AccountStatus;
  grants: GrantablePermission[];
}
