import type { AuthContext, GrantablePermission, Permission, Role } from "./types";
import { GRANTABLE_PERMISSIONS } from "./types";

export function isGrantable(p: string): p is GrantablePermission {
  return (GRANTABLE_PERMISSIONS as readonly string[]).includes(p);
}

/** May the caller open the admin area at all? */
export function canAccessAdmin(ctx: AuthContext): boolean {
  return ctx.status === "active" && (ctx.role === "owner" || ctx.role === "admin");
}

/** OWNER: everything. ADMIN: only explicit grants (never `roles.manage`). USER: nothing. */
export function can(ctx: AuthContext, permission: Permission): boolean {
  if (ctx.status !== "active") return false;
  if (ctx.role === "owner") return true;
  if (ctx.role === "admin") return isGrantable(permission) && ctx.grants.includes(permission);
  return false;
}

/** Which accounts may the actor administer? Nobody touches the OWNER or themselves. */
export function canManageTarget(actor: AuthContext, target: { id: string; role: Role }): boolean {
  if (actor.userId === target.id) return false;
  if (target.role === "owner") return false;
  if (actor.role === "owner") return true;
  if (actor.role === "admin") return target.role === "user";
  return false;
}
