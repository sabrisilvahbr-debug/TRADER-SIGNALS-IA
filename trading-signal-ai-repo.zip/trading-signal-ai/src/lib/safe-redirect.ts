/** Only same-site relative paths are accepted (prevents open redirects via `?next=`). */
export function safeNextPath(next: string | null | undefined, fallback = "/dashboard"): string {
  if (!next) return fallback;
  if (!next.startsWith("/") || next.startsWith("//") || next.startsWith("/\\")) return fallback;
  return next;
}

/** Same-origin check for cookie-authenticated mutations (CSRF defence in depth). */
export function isSameOrigin(originHeader: string | null, requestUrl: string): boolean {
  if (!originHeader) return true; // non-browser clients; browsers always send Origin on PATCH/POST
  try {
    return new URL(originHeader).origin === new URL(requestUrl).origin;
  } catch {
    return false;
  }
}
