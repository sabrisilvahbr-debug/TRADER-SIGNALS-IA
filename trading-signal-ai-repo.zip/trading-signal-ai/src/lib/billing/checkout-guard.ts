import type { AuthContext } from "@/lib/authz/types";

export type CheckoutDecision =
  | { allowed: true }
  | { allowed: false; status: 403 | 409; code: "owner_exempt" | "account_suspended" };

/**
 * Decided in the backend BEFORE any Stripe call. The OWNER is billing-exempt: no Checkout
 * Session, no Stripe Customer, no subscription.
 */
export function decideCheckout(ctx: AuthContext): CheckoutDecision {
  if (ctx.status !== "active") return { allowed: false, status: 403, code: "account_suspended" };
  if (ctx.role === "owner") return { allowed: false, status: 409, code: "owner_exempt" };
  return { allowed: true };
}
