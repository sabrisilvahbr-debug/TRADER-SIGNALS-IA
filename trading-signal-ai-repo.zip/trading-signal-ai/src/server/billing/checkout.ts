import { decideCheckout } from "@/lib/billing/checkout-guard";
import type { HandlerDeps, HandlerResult } from "@/server/admin/types";

/**
 * Slice 1: only the guard is wired. The Stripe Checkout Session itself arrives with the
 * billing phase; until then paying customers get an explicit 501 instead of a fake flow.
 */
export async function handleCheckout(deps: HandlerDeps): Promise<HandlerResult> {
  const ctx = await deps.getAuthContext();
  if (!ctx) return { status: 401, body: { error: "unauthenticated" } };

  const rl = deps.limiter.check(`checkout:${ctx.userId}`);
  if (!rl.ok) return { status: 429, body: { error: "rate_limited" }, headers: { "Retry-After": String(rl.retryAfterSec) } };

  const decision = decideCheckout(ctx);
  if (!decision.allowed) {
    if (decision.code === "owner_exempt") {
      await deps.audit.write({
        actorId: ctx.userId,
        actorRole: ctx.role,
        action: "billing.checkout_skipped_owner_exempt",
        result: "denied",
      });
    }
    return { status: decision.status, body: { error: decision.code } };
  }
  return { status: 501, body: { error: "billing_not_enabled" } };
}
