import "server-only";
import { cookies } from "next/headers";
import { DEFAULT_LOCALE, LOCALE_COOKIE, getDictionary, isLocale, type Locale } from "@/i18n";

/** Locale for public pages (no session lookup): cookie, then default. */
export async function getPublicLocale(): Promise<Locale> {
  const v = (await cookies()).get(LOCALE_COOKIE)?.value;
  return isLocale(v) ? v : DEFAULT_LOCALE;
}

export async function getPublicDictionary() {
  const locale = await getPublicLocale();
  return { locale, d: getDictionary(locale) };
}
