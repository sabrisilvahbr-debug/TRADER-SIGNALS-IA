import "server-only";
import { cache } from "react";
import { createAdminClient } from "@/lib/supabase/admin";
import { PLAN_KEYS, type PlanCatalog, type PlanDefinition, type PlanKey } from "@/lib/authz/plans";

interface PlanRow {
  key: PlanKey;
  name: string;
  max_assets: number;
  timeframes: string[];
  history_days: number;
  features: string[];
  published: boolean;
  price_monthly_cents: number | null;
  price_yearly_cents: number | null;
  currency: string | null;
}

/** Limits live in the database (central configuration). On failure returns {} => fail closed. */
export const loadPlanCatalog = cache(async (): Promise<Partial<PlanCatalog>> => {
  try {
    const { data, error } = await createAdminClient()
      .from("plans")
      .select("key,name,max_assets,timeframes,history_days,features,published,price_monthly_cents,price_yearly_cents,currency");
    if (error || !data) return {};
    const out: Partial<Record<PlanKey, PlanDefinition>> = {};
    for (const r of data as PlanRow[]) {
      if (!PLAN_KEYS.includes(r.key)) continue;
      out[r.key] = {
        key: r.key,
        name: r.name,
        maxAssets: r.max_assets,
        timeframes: r.timeframes,
        historyDays: r.history_days,
        features: r.features,
        published: r.published,
        priceMonthlyCents: r.price_monthly_cents,
        priceYearlyCents: r.price_yearly_cents,
        currency: r.currency,
      };
    }
    return out;
  } catch {
    return {};
  }
});
