import "server-only";
import { cache } from "react";
import { redirect } from "next/navigation";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { can, canAccessAdmin } from "@/lib/authz/permissions";
import { isGrantable } from "@/lib/authz/permissions";
import type { AuthContext, GrantablePermission, Permission, Role, AccountStatus } from "@/lib/authz/types";
import {
  resolveEffectiveAccess,
  type EffectiveAccess,
  type PlanKey,
  type SubscriptionLite,
  type SubscriptionStatus,
} from "@/lib/authz/plans";
import { loadPlanCatalog } from "./plan-catalog";
import type { Locale } from "@/i18n";

export interface ProfileRow {
  id: string;
  email: string;
  display_name: string | null;
  locale: Locale;
  timezone: string;
  role: Role;
  status: AccountStatus;
  created_at: string;
}

export interface Session {
  auth: AuthContext;
  profile: ProfileRow;
  subscription: SubscriptionLite | null;
  access: EffectiveAccess;
}

/**
 * Identity comes from `auth.getUser()` (validated by Supabase Auth), never from cookies
 * alone or from anything the client sends. Role, status and grants are read from the
 * database with the service role, keyed by that verified user id.
 */
export const getAuthContext = cache(async (): Promise<{ auth: AuthContext; profile: ProfileRow } | null> => {
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) return null;
  const userId = data.user.id;

  const admin = createAdminClient();
  const { data: profile } = await admin
    .from("profiles")
    .select("id,email,display_name,locale,timezone,role,status,created_at")
    .eq("id", userId)
    .maybeSingle<ProfileRow>();
  if (!profile) return null;

  let grants: GrantablePermission[] = [];
  if (profile.role === "admin") {
    const { data: rows } = await admin.from("admin_grants").select("permission").eq("user_id", userId);
    grants = (rows ?? []).map((r: { permission: string }) => r.permission).filter(isGrantable);
  }
  return {
    profile,
    auth: { userId, email: profile.email, role: profile.role, status: profile.status, grants },
  };
});

export const getSession = cache(async (): Promise<Session | null> => {
  const base = await getAuthContext();
  if (!base) return null;
  const admin = createAdminClient();
  const { data: sub } = await admin
    .from("subscriptions")
    .select("plan_key,status,current_period_end,cancel_at_period_end")
    .eq("user_id", base.auth.userId)
    .order("updated_at", { ascending: false })
    .limit(1)
    .maybeSingle<{ plan_key: PlanKey; status: SubscriptionStatus; current_period_end: string | null; cancel_at_period_end: boolean }>();

  const subscription: SubscriptionLite | null = sub
    ? {
        planKey: sub.plan_key,
        status: sub.status,
        currentPeriodEnd: sub.current_period_end ? new Date(sub.current_period_end) : null,
        cancelAtPeriodEnd: sub.cancel_at_period_end,
      }
    : null;

  const plans = await loadPlanCatalog();
  const access = resolveEffectiveAccess({ role: base.auth.role, subscription, plans });
  return { ...base, subscription, access };
});

export async function requireUser(): Promise<Session> {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.auth.status !== "active") redirect("/login?error=suspended");
  return session;
}

/** Server-side gate for /admin pages. Hiding links is NOT the security measure; this is. */
export async function requireAdmin(permission?: Permission): Promise<Session> {
  const session = await getSession();
  if (!session) redirect("/login?next=/admin");
  if (!canAccessAdmin(session.auth)) redirect("/dashboard?error=forbidden");
  if (permission && !can(session.auth, permission)) redirect("/admin?error=forbidden");
  return session;
}
