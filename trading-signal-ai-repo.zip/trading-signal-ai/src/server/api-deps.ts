import "server-only";
import { createRateLimiter } from "@/lib/rate-limit";
import { getAuthContext } from "./session";
import { supabaseAudit } from "./repos";
import type { HandlerDeps } from "./admin/types";
import { isSameOrigin } from "@/lib/safe-redirect";

const limiter = createRateLimiter({ limit: 30, windowMs: 60_000 });

export function apiDeps(): HandlerDeps {
  return {
    getAuthContext: async () => (await getAuthContext())?.auth ?? null,
    audit: supabaseAudit,
    limiter,
    log: (event) => console.error(JSON.stringify({ ts: new Date().toISOString(), ...event })),
  };
}

/** Structured JSON response, never cached. */
export function json(status: number, body: Record<string, unknown>, headers?: Record<string, string>) {
  return Response.json(body, { status, headers: { "Cache-Control": "no-store", ...headers } });
}

/** Browsers always send Origin on cross-site mutations; reject mismatches. */
export function rejectForeignOrigin(request: Request): Response | null {
  return isSameOrigin(request.headers.get("origin"), request.url) ? null : json(403, { error: "bad_origin" });
}
