import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";
import type { AuditEntry, AuditWriter, EngineRepo, TargetProfile, UserAdminRepo } from "./admin/types";
import type { FavoritesRepo } from "./favorites/service";
import type { GrantablePermission } from "@/lib/authz/types";

export const supabaseAudit: AuditWriter = {
  async write(e: AuditEntry) {
    const { error } = await createAdminClient().from("audit_logs").insert({
      actor_id: e.actorId,
      actor_role: e.actorRole,
      action: e.action,
      target_type: e.targetType ?? null,
      target_id: e.targetId ?? null,
      result: e.result,
      metadata: e.metadata ?? {},
    });
    if (error) throw new Error(`audit insert failed: ${error.code ?? "unknown"}`);
  },
};

export const supabaseUserAdminRepo: UserAdminRepo = {
  async getProfile(id): Promise<TargetProfile | null> {
    const { data } = await createAdminClient().from("profiles").select("id,role,status").eq("id", id).maybeSingle<TargetProfile>();
    return data ?? null;
  },

  async setStatus(id, status) {
    const db = createAdminClient();
    const { data: before } = await db.from("profiles").select("status").eq("id", id).neq("role", "owner").maybeSingle<{ status: string }>();
    if (!before) throw new Error("target not found or protected");
    const { error } = await db.from("profiles").update({ status }).eq("id", id).neq("role", "owner");
    if (error) throw new Error(`status update failed: ${error.code ?? "unknown"}`);
    // Ban/unban in Supabase Auth so existing refresh tokens stop working.
    const { error: banError } = await db.auth.admin.updateUserById(id, { ban_duration: status === "suspended" ? "876000h" : "none" });
    if (banError) {
      await db.from("profiles").update({ status: before.status }).eq("id", id);
      throw new Error("auth ban update failed");
    }
  },

  async setRole(id, role) {
    const db = createAdminClient();
    const { error } = await db.from("profiles").update({ role }).eq("id", id).neq("role", "owner");
    if (error) throw new Error(`role update failed: ${error.code ?? "unknown"}`);
    if (role === "user") {
      const { error: gErr } = await db.from("admin_grants").delete().eq("user_id", id);
      if (gErr) throw new Error("grants cleanup failed");
    }
  },

  async setGrants(id, grants: GrantablePermission[], grantedBy) {
    const db = createAdminClient();
    const { error: dErr } = await db.from("admin_grants").delete().eq("user_id", id);
    if (dErr) throw new Error("grants reset failed");
    if (grants.length === 0) return;
    const { error } = await db
      .from("admin_grants")
      .insert(grants.map((permission) => ({ user_id: id, permission, granted_by: grantedBy })));
    if (error) throw new Error("grants insert failed");
  },
};

export const supabaseEngineRepo: EngineRepo = {
  async setSignalsPaused(paused, updatedBy) {
    const { error } = await createAdminClient()
      .from("system_flags")
      .upsert({ key: "signals_paused", value: { paused }, updated_by: updatedBy, updated_at: new Date().toISOString() });
    if (error) throw new Error("flag update failed");
  },
};

/** Writes happen here (service role) because the client role can only read favorites. */
export const supabaseFavoritesRepo: FavoritesRepo = {
  async list(userId) {
    const { data } = await createAdminClient().from("user_favorites").select("symbol").eq("user_id", userId);
    return (data ?? []).map((r: { symbol: string }) => r.symbol);
  },
  async add(userId, symbol) {
    const { error } = await createAdminClient().from("user_favorites").upsert({ user_id: userId, symbol }, { onConflict: "user_id,symbol", ignoreDuplicates: true });
    if (error) throw new Error("favorite insert failed");
  },
  async remove(userId, symbol) {
    const { error } = await createAdminClient().from("user_favorites").delete().eq("user_id", userId).eq("symbol", symbol);
    if (error) throw new Error("favorite delete failed");
  },
};
