import { z } from "zod";
import { can, canAccessAdmin } from "@/lib/authz/permissions";
import type { EngineRepo, HandlerDeps, HandlerResult } from "./types";

const schema = z.object({ paused: z.boolean(), confirm: z.literal(true) });

/** Global safety pause for NEW signals. History is never edited. */
export async function handleEnginePause(deps: HandlerDeps & { repo: EngineRepo }, body: unknown): Promise<HandlerResult> {
  const ctx = await deps.getAuthContext();
  if (!ctx) return { status: 401, body: { error: "unauthenticated" } };

  const rl = deps.limiter.check(`admin:${ctx.userId}`);
  if (!rl.ok) return { status: 429, body: { error: "rate_limited" }, headers: { "Retry-After": String(rl.retryAfterSec) } };

  if (!canAccessAdmin(ctx) || !can(ctx, "engine.pause")) {
    await deps.audit.write({
      actorId: ctx.userId,
      actorRole: ctx.role,
      action: "engine.pause",
      result: "denied",
      metadata: { reason: "missing_permission" },
    });
    return { status: 403, body: { error: "forbidden" } };
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) return { status: 400, body: { error: "invalid_input" } };

  try {
    await deps.repo.setSignalsPaused(parsed.data.paused, ctx.userId);
  } catch (e) {
    deps.log?.({ level: "error", event: "engine_pause_failed", message: e instanceof Error ? e.message : "unknown" });
    await deps.audit.write({ actorId: ctx.userId, actorRole: ctx.role, action: "engine.pause", result: "error" }).catch(() => undefined);
    return { status: 500, body: { error: "internal_error" } };
  }
  try {
    await deps.audit.write({
      actorId: ctx.userId,
      actorRole: ctx.role,
      action: parsed.data.paused ? "engine.pause" : "engine.resume",
      targetType: "system_flag",
      targetId: "signals_paused",
      result: "success",
    });
  } catch (e) {
    deps.log?.({ level: "error", event: "audit_write_failed", message: e instanceof Error ? e.message : "unknown" });
    return { status: 500, body: { error: "audit_failed", applied: true } };
  }
  return { status: 200, body: { ok: true, paused: parsed.data.paused } };
}
