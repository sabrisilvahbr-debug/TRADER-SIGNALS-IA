import { z } from "zod";
import { can, canAccessAdmin, canManageTarget } from "@/lib/authz/permissions";
import { GRANTABLE_PERMISSIONS, type AuthContext, type Permission } from "@/lib/authz/types";
import type { HandlerDeps, HandlerResult, UserAdminRepo } from "./types";

export const userActionSchema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("suspend"), confirm: z.literal(true) }),
  z.object({ action: z.literal("reactivate"), confirm: z.literal(true) }),
  z.object({ action: z.literal("set_role"), role: z.enum(["admin", "user"]), confirm: z.literal(true) }),
  z.object({
    action: z.literal("set_grants"),
    grants: z.array(z.enum(GRANTABLE_PERMISSIONS)).max(GRANTABLE_PERMISSIONS.length),
    confirm: z.literal(true),
  }),
]);
export type UserAction = z.infer<typeof userActionSchema>;

const uuid = z.uuid();

function requiredPermission(action: UserAction["action"]): Permission {
  return action === "suspend" || action === "reactivate" ? "users.suspend" : "roles.manage";
}

export async function handleUserAdminAction(
  deps: HandlerDeps & { repo: UserAdminRepo },
  targetId: string,
  body: unknown,
): Promise<HandlerResult> {
  const ctx = await deps.getAuthContext();
  if (!ctx) return { status: 401, body: { error: "unauthenticated" } };

  const rl = deps.limiter.check(`admin:${ctx.userId}`);
  if (!rl.ok) return { status: 429, body: { error: "rate_limited" }, headers: { "Retry-After": String(rl.retryAfterSec) } };

  const audit = (a: { result: "success" | "denied" | "error"; action: string; metadata?: Record<string, unknown> }) =>
    deps.audit.write({ actorId: ctx.userId, actorRole: ctx.role, targetType: "profile", targetId, ...a });

  // Authorization before anything else: never reveal validation details to non-admins.
  if (!canAccessAdmin(ctx)) {
    await audit({ result: "denied", action: "admin.api_access", metadata: { reason: "not_admin" } });
    return { status: 403, body: { error: "forbidden" } };
  }

  if (!uuid.safeParse(targetId).success) return { status: 400, body: { error: "invalid_target" } };
  const parsed = userActionSchema.safeParse(body);
  if (!parsed.success) return { status: 400, body: { error: "invalid_input" } };
  const input = parsed.data;
  const actionName = `user.${input.action}`;

  if (!can(ctx, requiredPermission(input.action))) {
    await audit({ result: "denied", action: actionName, metadata: { reason: "missing_permission" } });
    return { status: 403, body: { error: "forbidden" } };
  }

  const target = await deps.repo.getProfile(targetId);
  if (!target) return { status: 404, body: { error: "not_found" } };

  if (!canManageTarget(ctx, target)) {
    await audit({ result: "denied", action: actionName, metadata: { reason: "target_not_allowed", targetRole: target.role } });
    return { status: 403, body: { error: "forbidden" } };
  }
  if (input.action === "set_grants" && target.role !== "admin") {
    return { status: 409, body: { error: "grants_only_for_admin" } };
  }

  try {
    await applyAction(deps.repo, ctx, targetId, input);
  } catch (e) {
    deps.log?.({ level: "error", event: "admin_action_failed", action: actionName, message: e instanceof Error ? e.message : "unknown" });
    await audit({ result: "error", action: actionName }).catch(() => undefined);
    return { status: 500, body: { error: "internal_error" } };
  }

  const metadata: Record<string, unknown> = { previousRole: target.role, previousStatus: target.status };
  if (input.action === "set_role") metadata.newRole = input.role;
  if (input.action === "set_grants") metadata.grants = input.grants;
  try {
    await audit({ result: "success", action: actionName, metadata });
  } catch (e) {
    // The change is already applied; surface the failure loudly instead of hiding it.
    deps.log?.({ level: "error", event: "audit_write_failed", action: actionName, message: e instanceof Error ? e.message : "unknown" });
    return { status: 500, body: { error: "audit_failed", applied: true } };
  }
  return { status: 200, body: { ok: true } };
}

async function applyAction(repo: UserAdminRepo, ctx: AuthContext, targetId: string, input: UserAction): Promise<void> {
  switch (input.action) {
    case "suspend":
      return repo.setStatus(targetId, "suspended");
    case "reactivate":
      return repo.setStatus(targetId, "active");
    case "set_role":
      return repo.setRole(targetId, input.role);
    case "set_grants":
      return repo.setGrants(targetId, input.grants, ctx.userId);
  }
}
