import type { AccountStatus, AuthContext, GrantablePermission, Role } from "@/lib/authz/types";
import type { RateLimiter } from "@/lib/rate-limit";

export interface AuditEntry {
  actorId: string | null;
  actorRole: Role | null;
  action: string;
  targetType?: string;
  targetId?: string;
  result: "success" | "denied" | "error";
  /** Never put credentials or unnecessary personal data here. */
  metadata?: Record<string, unknown>;
}
export interface AuditWriter {
  write(entry: AuditEntry): Promise<void>;
}

export interface TargetProfile {
  id: string;
  role: Role;
  status: AccountStatus;
}

export interface UserAdminRepo {
  getProfile(id: string): Promise<TargetProfile | null>;
  /** Also bans/unbans the account in Supabase Auth so existing sessions stop refreshing. */
  setStatus(id: string, status: AccountStatus): Promise<void>;
  /** Demoting to `user` also clears the admin grants. */
  setRole(id: string, role: "admin" | "user"): Promise<void>;
  setGrants(id: string, grants: GrantablePermission[], grantedBy: string): Promise<void>;
}

export interface EngineRepo {
  setSignalsPaused(paused: boolean, updatedBy: string): Promise<void>;
}

export interface HandlerDeps {
  /** Resolves the verified caller from the session (never from the request body). */
  getAuthContext(): Promise<AuthContext | null>;
  audit: AuditWriter;
  limiter: RateLimiter;
  log?: (event: Record<string, unknown>) => void;
}

export interface HandlerResult {
  status: number;
  body: Record<string, unknown>;
  headers?: Record<string, string>;
}
