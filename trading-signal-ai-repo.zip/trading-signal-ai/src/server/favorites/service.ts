import { z } from "zod";
import { assetLimitReached, SUPPORTED_ASSETS, type EffectiveAccess } from "@/lib/authz/plans";

export interface FavoritesRepo {
  list(userId: string): Promise<string[]>;
  add(userId: string, symbol: string): Promise<void>;
  remove(userId: string, symbol: string): Promise<void>;
}

export type FavoriteResult =
  | { ok: true }
  | { ok: false; code: "invalid_symbol" | "limit_reached" | "suspended" };

const symbolSchema = z.enum(SUPPORTED_ASSETS);

/**
 * `userId` ALWAYS comes from the verified session, never from the request, so a user cannot
 * touch another user's favorites by tampering with ids. The plan limit is enforced here
 * (the database only allows reads for the client role).
 */
export async function addFavorite(
  repo: FavoritesRepo,
  who: { userId: string; status: "active" | "suspended" },
  access: EffectiveAccess,
  symbolInput: unknown,
): Promise<FavoriteResult> {
  if (who.status !== "active") return { ok: false, code: "suspended" };
  const symbol = symbolSchema.safeParse(symbolInput);
  if (!symbol.success) return { ok: false, code: "invalid_symbol" };

  const current = await repo.list(who.userId);
  if (current.includes(symbol.data)) return { ok: true }; // idempotent
  if (assetLimitReached(access, current.length)) return { ok: false, code: "limit_reached" };
  await repo.add(who.userId, symbol.data);
  return { ok: true };
}

export async function removeFavorite(
  repo: FavoritesRepo,
  who: { userId: string; status: "active" | "suspended" },
  symbolInput: unknown,
): Promise<FavoriteResult> {
  if (who.status !== "active") return { ok: false, code: "suspended" };
  const symbol = symbolSchema.safeParse(symbolInput);
  if (!symbol.success) return { ok: false, code: "invalid_symbol" };
  await repo.remove(who.userId, symbol.data);
  return { ok: true };
}
