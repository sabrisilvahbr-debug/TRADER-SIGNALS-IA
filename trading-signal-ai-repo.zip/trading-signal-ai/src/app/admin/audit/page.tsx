import { Card } from "@/components/ui";
import { getDictionary } from "@/i18n";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAdmin } from "@/server/session";

interface Log {
  id: number;
  created_at: string;
  actor_id: string | null;
  actor_role: string | null;
  action: string;
  target_type: string | null;
  target_id: string | null;
  result: string;
}

export default async function AuditPage() {
  const s = await requireAdmin("audit.read");
  const d = getDictionary(s.profile.locale);
  const t = d.admin.audit;
  const { data } = await createAdminClient().from("audit_logs").select("id,created_at,actor_id,actor_role,action,target_type,target_id,result").order("id", { ascending: false }).limit(100);
  const rows = (data ?? []) as Log[];
  const short = (v: string | null) => (v ? v.slice(0, 8) : "—");
  return (
    <>
      <h1 className="text-2xl font-bold">{t.title}</h1>
      <Card className="overflow-x-auto">
        {rows.length === 0 ? (
          <p className="text-sm">{t.empty}</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-[var(--line)]">
                <th className="py-2 pr-3">{t.when}</th>
                <th className="pr-3">{t.actor}</th>
                <th className="pr-3">{t.action}</th>
                <th className="pr-3">{t.target}</th>
                <th className="pr-3">{t.result}</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-b border-[var(--line)]">
                  <td className="py-2 pr-3">{r.created_at.replace("T", " ").slice(0, 19)}</td>
                  <td className="pr-3 font-mono text-xs">
                    {short(r.actor_id)} {r.actor_role ? `(${r.actor_role})` : ""}
                  </td>
                  <td className="pr-3">{r.action}</td>
                  <td className="pr-3 font-mono text-xs">
                    {r.target_type ?? "—"}:{short(r.target_id)}
                  </td>
                  <td className="pr-3">{r.result}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </>
  );
}
