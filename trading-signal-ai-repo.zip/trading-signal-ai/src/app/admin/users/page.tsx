import { Card, btnCls, first, inputCls } from "@/components/ui";
import { UserActions } from "@/components/UserActions";
import { can } from "@/lib/authz/permissions";
import { isGrantable } from "@/lib/authz/permissions";
import { resolveEffectiveAccess, type PlanKey, type SubscriptionStatus } from "@/lib/authz/plans";
import type { GrantablePermission, Role, AccountStatus } from "@/lib/authz/types";
import { getDictionary } from "@/i18n";
import { createAdminClient } from "@/lib/supabase/admin";
import { loadPlanCatalog } from "@/server/plan-catalog";
import { requireAdmin } from "@/server/session";

interface Row {
  id: string;
  email: string;
  role: Role;
  status: AccountStatus;
  created_at: string;
}

export default async function UsersPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const s = await requireAdmin("users.read");
  const sp = await searchParams;
  const d = getDictionary(s.profile.locale);
  const t = d.admin.users;
  const q = (first(sp.q) ?? "").trim().slice(0, 100);

  const db = createAdminClient();
  let query = db.from("profiles").select("id,email,role,status,created_at").order("created_at", { ascending: false }).limit(50);
  if (q) query = query.ilike("email", `%${q}%`);
  const { data } = await query;
  const rows = (data ?? []) as Row[];
  const ids = rows.map((r) => r.id);

  const [{ data: subs }, { data: grantRows }, plans] = await Promise.all([
    ids.length ? db.from("subscriptions").select("user_id,plan_key,status,current_period_end,cancel_at_period_end").in("user_id", ids).order("updated_at", { ascending: false }) : Promise.resolve({ data: [] }),
    s.auth.role === "owner" && ids.length ? db.from("admin_grants").select("user_id,permission").in("user_id", ids) : Promise.resolve({ data: [] }),
    loadPlanCatalog(),
  ]);

  const subByUser = new Map<string, { plan_key: PlanKey; status: SubscriptionStatus; current_period_end: string | null; cancel_at_period_end: boolean }>();
  for (const r of (subs ?? []) as { user_id: string; plan_key: PlanKey; status: SubscriptionStatus; current_period_end: string | null; cancel_at_period_end: boolean }[]) {
    if (!subByUser.has(r.user_id)) subByUser.set(r.user_id, r);
  }
  const grantsByUser = new Map<string, GrantablePermission[]>();
  for (const g of (grantRows ?? []) as { user_id: string; permission: string }[]) {
    if (!isGrantable(g.permission)) continue;
    grantsByUser.set(g.user_id, [...(grantsByUser.get(g.user_id) ?? []), g.permission]);
  }

  const labels = {
    suspend: t.suspend,
    reactivate: t.reactivate,
    confirmSuspend: t.confirmSuspend,
    confirmReactivate: t.confirmReactivate,
    roleLabel: t.roleLabel,
    grants: t.grants,
    saveRole: t.saveRole,
    confirmRole: t.confirmRole,
    protected: t.protected,
    done: t.done,
    failed: t.failed,
    roles: { admin: d.roles.admin, user: d.roles.user },
    grantNames: t.grantNames,
  };

  return (
    <>
      <h1 className="text-2xl font-bold">{t.title}</h1>
      <form className="flex gap-2" role="search">
        <input name="q" defaultValue={q} placeholder={t.searchPlaceholder} aria-label={t.searchPlaceholder} className={`${inputCls} mt-0 max-w-xs`} maxLength={100} />
        <button className={btnCls}>{d.common.search}</button>
      </form>
      <Card className="overflow-x-auto">
        {rows.length === 0 ? (
          <p className="text-sm">{t.noResults}</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-[var(--line)]">
                <th className="py-2 pr-3">{t.email}</th>
                <th className="pr-3">{t.role}</th>
                <th className="pr-3">{t.status}</th>
                <th className="pr-3">{t.plan}</th>
                <th className="pr-3">{t.created}</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const sub = subByUser.get(r.id);
                const access = resolveEffectiveAccess({
                  role: r.role,
                  plans,
                  subscription: sub ? { planKey: sub.plan_key, status: sub.status, currentPeriodEnd: sub.current_period_end ? new Date(sub.current_period_end) : null, cancelAtPeriodEnd: sub.cancel_at_period_end } : null,
                });
                return (
                  <tr key={r.id} className="border-b border-[var(--line)] align-top">
                    <td className="py-2 pr-3">{r.email}</td>
                    <td className="pr-3">{d.roles[r.role]}</td>
                    <td className="pr-3">{d.statuses[r.status]}</td>
                    <td className="pr-3">{access.label === "OWNER" ? "OWNER" : d.plan.names[access.label]}</td>
                    <td className="pr-3">{r.created_at.slice(0, 10)}</td>
                    <td className="py-2">
                      <UserActions
                        target={{ id: r.id, role: r.role, status: r.status, grants: grantsByUser.get(r.id) ?? [] }}
                        viewer={{ isOwner: s.auth.role === "owner", canSuspend: can(s.auth, "users.suspend"), isSelf: r.id === s.auth.userId }}
                        labels={labels}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </Card>
    </>
  );
}
