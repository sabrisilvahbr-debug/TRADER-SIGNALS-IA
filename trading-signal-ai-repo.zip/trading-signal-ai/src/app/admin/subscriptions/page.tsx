import { Card } from "@/components/ui";
import { getDictionary } from "@/i18n";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAdmin } from "@/server/session";

interface Sub {
  user_id: string;
  stripe_customer_id: string;
  plan_key: string;
  status: string;
  current_period_end: string | null;
  cancel_at_period_end: boolean;
}

export default async function SubscriptionsAdminPage() {
  const s = await requireAdmin("billing.read");
  const d = getDictionary(s.profile.locale);
  const t = d.admin.subscriptions;
  const db = createAdminClient();
  const { data } = await db.from("subscriptions").select("user_id,stripe_customer_id,plan_key,status,current_period_end,cancel_at_period_end").order("updated_at", { ascending: false }).limit(100);
  const rows = (data ?? []) as Sub[];
  const { data: profs } = rows.length ? await db.from("profiles").select("id,email").in("id", rows.map((r) => r.user_id)) : { data: [] };
  const email = new Map(((profs ?? []) as { id: string; email: string }[]).map((p) => [p.id, p.email]));

  return (
    <>
      <h1 className="text-2xl font-bold">{t.title}</h1>
      <Card className="overflow-x-auto">
        {rows.length === 0 ? (
          <p className="text-sm">{t.empty}</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-[var(--line)]">
                <th className="py-2 pr-3">{d.admin.users.email}</th>
                <th className="pr-3">{d.admin.users.plan}</th>
                <th className="pr-3">{d.admin.users.status}</th>
                <th className="pr-3">{t.customer}</th>
                <th className="pr-3">{t.period}</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={`${r.user_id}-${r.stripe_customer_id}-${r.status}`} className="border-b border-[var(--line)]">
                  <td className="py-2 pr-3">{email.get(r.user_id) ?? "—"}</td>
                  <td className="pr-3">{r.plan_key}</td>
                  <td className="pr-3">
                    {r.status}
                    {r.cancel_at_period_end ? ` (${t.cancelScheduled})` : ""}
                  </td>
                  <td className="pr-3 font-mono text-xs">{r.stripe_customer_id}</td>
                  <td className="pr-3">{r.current_period_end?.slice(0, 10) ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </>
  );
}
