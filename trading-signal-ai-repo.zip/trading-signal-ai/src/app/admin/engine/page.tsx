import { Card } from "@/components/ui";
import { EnginePauseButton } from "@/components/EnginePauseButton";
import { can } from "@/lib/authz/permissions";
import { getDictionary } from "@/i18n";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAdmin } from "@/server/session";

export default async function EnginePage() {
  const s = await requireAdmin("engine.read");
  const d = getDictionary(s.profile.locale);
  const t = d.admin.engine;
  const o = d.admin.overview;
  const { data } = await createAdminClient().from("system_flags").select("value,updated_at").eq("key", "signals_paused").maybeSingle<{ value: { paused?: boolean }; updated_at: string }>();
  const paused = data?.value?.paused === true;
  return (
    <>
      <h1 className="text-2xl font-bold">{t.title}</h1>
      <Card>
        <ul className="space-y-1 text-sm">
          <li>
            {o.signalsPaused}: <strong>{paused ? o.pausedYes : o.pausedNo}</strong>
          </li>
          <li>
            {o.worker}: {o.workerOff}
          </li>
          <li>
            {o.lastData}: {d.common.notAvailable}
          </li>
        </ul>
        <p className="mt-3 text-xs text-[var(--muted)]">{t.note}</p>
        {can(s.auth, "engine.pause") ? (
          <div className="mt-4">
            <EnginePauseButton paused={paused} labels={{ pause: t.pause, resume: t.resume, confirmPause: t.confirmPause, confirmResume: t.confirmResume, failed: d.admin.users.failed }} />
          </div>
        ) : null}
      </Card>
    </>
  );
}
