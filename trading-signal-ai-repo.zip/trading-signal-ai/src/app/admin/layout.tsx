import Link from "next/link";
import type { ReactNode } from "react";
import { can } from "@/lib/authz/permissions";
import type { Permission } from "@/lib/authz/types";
import { getDictionary } from "@/i18n";
import { requireAdmin } from "@/server/session";
import { LocaleSwitcher } from "@/components/LocaleSwitcher";
import { planBadge } from "@/components/DashboardShell";

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const session = await requireAdmin();
  const d = getDictionary(session.profile.locale);
  const items: [string, string, Permission | null][] = [
    ["/admin", d.admin.nav.overview, null],
    ["/admin/users", d.admin.nav.users, "users.read"],
    ["/admin/subscriptions", d.admin.nav.subscriptions, "billing.read"],
    ["/admin/plans", d.admin.nav.plans, "plans.read"],
    ["/admin/engine", d.admin.nav.engine, "engine.read"],
    ["/admin/audit", d.admin.nav.audit, "audit.read"],
  ];
  return (
    <div className="min-h-screen">
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--line)] px-4 py-3 text-sm">
        <div className="flex items-center gap-4">
          <strong>{d.admin.title}</strong>
          <span className="rounded-full border border-[var(--line)] px-3 py-1 font-semibold">{planBadge(session, d)}</span>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/dashboard" className="underline">
            {d.dashboard.nav.overview}
          </Link>
          <LocaleSwitcher current={session.profile.locale} label={d.common.language} />
        </div>
      </header>
      <nav aria-label="Admin" className="flex flex-wrap gap-4 border-b border-[var(--line)] px-4 py-2 text-sm">
        {items
          .filter(([, , perm]) => perm === null || can(session.auth, perm))
          .map(([href, label]) => (
            <Link key={href} href={href} className="hover:underline">
              {label}
            </Link>
          ))}
      </nav>
      <main className="mx-auto max-w-5xl space-y-6 px-4 py-8">{children}</main>
    </div>
  );
}
