import { Alert, Card, first } from "@/components/ui";
import { can } from "@/lib/authz/permissions";
import { getDictionary } from "@/i18n";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAdmin } from "@/server/session";

// Loosely typed on purpose: Supabase filter builders have very deep generic types.
type Filter = (q: any) => any; // eslint-disable-line @typescript-eslint/no-explicit-any

async function count(table: string, apply?: Filter): Promise<number> {
  const base: any = createAdminClient().from(table).select("*", { count: "exact", head: true }); // eslint-disable-line @typescript-eslint/no-explicit-any
  const { count: c } = await (apply ? apply(base) : base);
  return c ?? 0;
}

export default async function AdminOverview({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const s = await requireAdmin();
  const sp = await searchParams;
  const d = getDictionary(s.profile.locale);
  const o = d.admin.overview;
  const day = 86_400_000;
  const since = (n: number) => new Date(Date.now() - n * day).toISOString();

  const db = createAdminClient();
  const [users, week, month, suspended] = can(s.auth, "users.read")
    ? await Promise.all([
        count("profiles"),
        count("profiles", (q) => q.gte("created_at", since(7))),
        count("profiles", (q) => q.gte("created_at", since(30))),
        count("profiles", (q) => q.eq("status", "suspended")),
      ])
    : [null, null, null, null];
  const [subActive, subPastDue, subCanceled] = can(s.auth, "billing.read")
    ? await Promise.all([
        count("subscriptions", (q) => q.in("status", ["active", "trialing"])),
        count("subscriptions", (q) => q.eq("status", "past_due")),
        count("subscriptions", (q) => q.eq("status", "canceled")),
      ])
    : [null, null, null];
  const flag = can(s.auth, "engine.read")
    ? (await db.from("system_flags").select("value").eq("key", "signals_paused").maybeSingle<{ value: { paused?: boolean } }>()).data
    : null;

  const Stat = ({ label, value }: { label: string; value: number | string | null }) =>
    value === null ? null : (
      <Card>
        <p className="text-sm text-[var(--muted)]">{label}</p>
        <p className="mt-1 text-2xl font-semibold">{value}</p>
      </Card>
    );

  return (
    <>
      <h1 className="text-2xl font-bold">{d.admin.nav.overview}</h1>
      {first(sp.error) === "forbidden" ? <Alert kind="error">{d.errors.forbidden}</Alert> : null}
      <div className="grid gap-4 md:grid-cols-3">
        <Stat label={o.totalUsers} value={users} />
        <Stat label={o.newWeek} value={week} />
        <Stat label={o.newMonth} value={month} />
        <Stat label={o.activeAccounts} value={users === null || suspended === null ? null : users - suspended} />
        <Stat label={o.suspended} value={suspended} />
        <Stat label={o.subsActive} value={subActive} />
        <Stat label={o.subsPastDue} value={subPastDue} />
        <Stat label={o.subsCanceled} value={subCanceled} />
      </div>
      {can(s.auth, "billing.read") ? (
        <Card>
          <h2 className="font-semibold">{o.mrr}</h2>
          <p className="mt-2 text-sm text-[var(--muted)]">{d.common.notAvailable} — {o.mrrNote}</p>
        </Card>
      ) : null}
      {can(s.auth, "engine.read") ? (
        <Card>
          <h2 className="font-semibold">{o.engine}</h2>
          <ul className="mt-2 space-y-1 text-sm">
            <li>
              {o.signalsPaused}: <strong>{flag?.value?.paused ? o.pausedYes : o.pausedNo}</strong>
            </li>
            <li>
              {o.worker}: {o.workerOff}
            </li>
            <li>
              {o.lastData}: {d.common.notAvailable}
            </li>
          </ul>
        </Card>
      ) : null}
    </>
  );
}
