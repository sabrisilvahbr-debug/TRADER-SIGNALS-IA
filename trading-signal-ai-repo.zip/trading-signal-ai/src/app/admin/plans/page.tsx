import { Alert, Card } from "@/components/ui";
import { PLAN_KEYS } from "@/lib/authz/plans";
import { getDictionary } from "@/i18n";
import { loadPlanCatalog } from "@/server/plan-catalog";
import { requireAdmin } from "@/server/session";

export default async function PlansAdminPage() {
  const s = await requireAdmin("plans.read");
  const d = getDictionary(s.profile.locale);
  const t = d.admin.plans;
  const plans = await loadPlanCatalog();
  return (
    <>
      <h1 className="text-2xl font-bold">{t.title}</h1>
      <Alert kind="warn">{t.readOnly}</Alert>
      <div className="grid gap-4 md:grid-cols-3">
        {PLAN_KEYS.map((k) => {
          const p = plans[k];
          return (
            <Card key={k}>
              <h2 className="font-semibold">{d.plan.names[k]}</h2>
              <p className="text-sm text-[var(--muted)]">{p?.published ? t.published : t.unpublished}</p>
              {p ? (
                <ul className="mt-3 space-y-1 text-sm">
                  <li>
                    {d.plan.assets}: {p.maxAssets}
                  </li>
                  <li>
                    {d.plan.timeframes}: {p.timeframes.join(", ") || "—"}
                  </li>
                  <li>
                    {d.plan.history}: {p.historyDays} {d.plan.days}
                  </li>
                  {p.features.map((f) => (
                    <li key={f}>✓ {d.plan.features[f as keyof typeof d.plan.features] ?? f}</li>
                  ))}
                </ul>
              ) : null}
            </Card>
          );
        })}
      </div>
    </>
  );
}
