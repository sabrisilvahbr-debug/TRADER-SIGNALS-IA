import { PublicShell } from "@/components/PublicShell";
import { Card } from "@/components/ui";
import { PLAN_KEYS } from "@/lib/authz/plans";
import { getPublicDictionary } from "@/server/locale";
import { loadPlanCatalog } from "@/server/plan-catalog";

export default async function PricingPage() {
  const { d } = await getPublicDictionary();
  const plans = await loadPlanCatalog();

  return (
    <PublicShell>
      <h1 className="text-3xl font-bold">{d.pricing.title}</h1>
      <p className="mt-2 text-[var(--muted)]">{d.pricing.subtitle}</p>
      <div className="mt-8 grid gap-4 md:grid-cols-3">
        {PLAN_KEYS.map((key) => {
          const p = plans[key];
          return (
            <Card key={key}>
              <h2 className="text-xl font-semibold">{d.plan.names[key]}</h2>
              <p className="mt-1 text-sm text-[var(--muted)]">
                {p?.published ? d.plan.available : d.plan.comingSoon} · {d.plan.priceTbd}
              </p>
              {p ? (
                <ul className="mt-4 space-y-1 text-sm">
                  <li>
                    {d.plan.assets}: {p.maxAssets}
                  </li>
                  <li>
                    {d.plan.timeframes}: {p.timeframes.join(", ") || "—"}
                  </li>
                  <li>
                    {d.plan.history}: {p.historyDays} {d.plan.days}
                  </li>
                  {p.features.map((f) => (
                    <li key={f}>✓ {d.plan.features[f as keyof typeof d.plan.features] ?? f}</li>
                  ))}
                </ul>
              ) : null}
              {key !== "free" ? <p className="mt-4 text-xs text-[var(--muted)]">{d.pricing.soon}</p> : null}
            </Card>
          );
        })}
      </div>
    </PublicShell>
  );
}
