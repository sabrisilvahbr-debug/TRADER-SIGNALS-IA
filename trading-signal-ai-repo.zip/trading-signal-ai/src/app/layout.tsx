import type { Metadata } from "next";
import "./globals.css";
import { getPublicLocale } from "@/server/locale";

export const metadata: Metadata = {
  title: "Trading Signal AI",
  description: "Crypto technical signals, explained and auditable. / Sinais técnicos de criptomoedas, explicados e auditáveis.",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const locale = await getPublicLocale();
  return (
    <html lang={locale}>
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
