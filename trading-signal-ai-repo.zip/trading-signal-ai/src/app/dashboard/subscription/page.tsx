import { Card } from "@/components/ui";
import { planBadge } from "@/components/DashboardShell";
import { getDictionary } from "@/i18n";
import { requireUser } from "@/server/session";

export default async function SubscriptionPage() {
  const s = await requireUser();
  const d = getDictionary(s.profile.locale);
  const t = d.dashboard.subscription;
  const owner = s.access.billingExempt;
  const p = s.access.plan;
  return (
    <>
      <h1 className="text-2xl font-bold">{t.title}</h1>
      <Card>
        <h2 className="font-semibold">{t.current}</h2>
        <p className="mt-2 text-lg">{planBadge(s, d)}</p>
        <p className="mt-1 text-sm text-[var(--muted)]">
          {t.reason}: {t.reasons[s.access.reason]}
        </p>
        <p className="mt-3 text-sm">{owner ? t.ownerText : s.access.label === "free" ? t.freeText : null}</p>
        <ul className="mt-3 space-y-1 text-sm">
          <li>
            {d.plan.assets}: {p.maxAssets}
          </li>
          <li>
            {d.plan.timeframes}: {p.timeframes.join(", ") || "—"}
          </li>
          <li>
            {d.plan.history}: {p.historyDays} {d.plan.days}
          </li>
        </ul>
        {!owner ? <p className="mt-4 text-sm text-[var(--muted)]">{t.manage}</p> : null}
      </Card>
    </>
  );
}
