import type { ReactNode } from "react";
import { DashboardShell } from "@/components/DashboardShell";
import { requireUser } from "@/server/session";

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const session = await requireUser();
  return <DashboardShell session={session}>{children}</DashboardShell>;
}
