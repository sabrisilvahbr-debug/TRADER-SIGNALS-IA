import { notFound } from "next/navigation";
import { Card } from "@/components/ui";
import { getDictionary } from "@/i18n";
import { requireUser } from "@/server/session";

const SECTIONS = ["market", "charts", "signals", "history", "stats", "alerts"] as const;
type Section = (typeof SECTIONS)[number];

export default async function SectionPage({ params }: { params: Promise<{ section: string }> }) {
  const { section } = await params;
  if (!(SECTIONS as readonly string[]).includes(section)) notFound();
  const s = await requireUser();
  const d = getDictionary(s.profile.locale);
  return (
    <>
      <h1 className="text-2xl font-bold">{d.dashboard.nav[section as Section]}</h1>
      <Card>
        <h2 className="font-semibold">{d.dashboard.empty.title}</h2>
        <p className="mt-2 text-sm text-[var(--muted)]">{d.dashboard.empty.text}</p>
      </Card>
    </>
  );
}
