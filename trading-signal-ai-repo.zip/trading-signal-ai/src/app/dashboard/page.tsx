import { Alert, Card, first } from "@/components/ui";
import { planBadge } from "@/components/DashboardShell";
import { getDictionary } from "@/i18n";
import { requireUser } from "@/server/session";
import { createAdminClient } from "@/lib/supabase/admin";

export default async function OverviewPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const s = await requireUser();
  const sp = await searchParams;
  const d = getDictionary(s.profile.locale);
  const o = d.dashboard.overview;
  const p = s.access.plan;

  const { data: flag } = await createAdminClient().from("system_flags").select("value").eq("key", "signals_paused").maybeSingle<{ value: { paused?: boolean } }>();
  const paused = flag?.value?.paused === true;

  return (
    <>
      <h1 className="text-2xl font-bold">
        {o.welcome}
        {s.profile.display_name ? `, ${s.profile.display_name}` : ""}
      </h1>
      {first(sp.error) === "forbidden" ? <Alert kind="error">{d.errors.forbidden}</Alert> : null}
      {paused ? <Alert kind="warn">{o.paused}</Alert> : null}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <h2 className="font-semibold">{o.yourPlan}</h2>
          <p className="mt-2 text-lg">{planBadge(s, d)}</p>
          <p className="mt-1 text-sm text-[var(--muted)]">
            {o.role}: {d.roles[s.auth.role]}
          </p>
        </Card>
        <Card>
          <h2 className="font-semibold">{o.limits}</h2>
          <ul className="mt-2 space-y-1 text-sm">
            <li>
              {d.plan.assets}: {p.maxAssets}
            </li>
            <li>
              {d.plan.timeframes}: {p.timeframes.join(", ") || "—"}
            </li>
            <li>
              {d.plan.history}: {p.historyDays} {d.plan.days}
            </li>
          </ul>
        </Card>
        <Card className="md:col-span-2">
          <h2 className="font-semibold">{o.engine}</h2>
          <p className="mt-2 text-sm text-[var(--muted)]">{o.engineOff}</p>
        </Card>
      </div>
    </>
  );
}
