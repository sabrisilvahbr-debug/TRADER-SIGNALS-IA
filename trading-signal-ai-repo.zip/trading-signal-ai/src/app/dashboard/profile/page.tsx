import { Alert, Card, Field, btnCls, first, inputCls } from "@/components/ui";
import { LOCALES, getDictionary } from "@/i18n";
import { requireUser } from "@/server/session";
import { updateProfileAction } from "../actions";

export default async function ProfilePage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const s = await requireUser();
  const sp = await searchParams;
  const d = getDictionary(s.profile.locale);
  const t = d.dashboard.profile;
  const errCode = first(sp.error);
  return (
    <>
      <h1 className="text-2xl font-bold">{t.title}</h1>
      {errCode ? <Alert kind="error">{d.errors[errCode as keyof typeof d.errors] ?? d.errors.generic}</Alert> : null}
      {first(sp.ok) ? <Alert kind="ok">{d.common.saved}</Alert> : null}
      <Card>
        <form action={updateProfileAction} className="max-w-md space-y-4">
          <p className="text-sm">
            <span className="font-medium">{t.email}:</span> {s.profile.email}
          </p>
          <Field label={t.name}>
            <input className={inputCls} name="display_name" defaultValue={s.profile.display_name ?? ""} maxLength={80} />
          </Field>
          <Field label={d.common.language}>
            <select className={inputCls} name="locale" defaultValue={s.profile.locale}>
              {LOCALES.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </Field>
          <Field label={t.timezone}>
            <input className={inputCls} name="timezone" defaultValue={s.profile.timezone} required maxLength={64} />
          </Field>
          <button className={btnCls}>{d.common.save}</button>
        </form>
      </Card>
    </>
  );
}
