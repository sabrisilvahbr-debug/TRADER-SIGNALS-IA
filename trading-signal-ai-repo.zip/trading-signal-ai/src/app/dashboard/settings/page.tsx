import { Alert, Card, btnCls, first } from "@/components/ui";
import { getDictionary } from "@/i18n";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { requireUser } from "@/server/session";
import { updateSettingsAction } from "../actions";

export default async function SettingsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const s = await requireUser();
  const sp = await searchParams;
  const d = getDictionary(s.profile.locale);
  const t = d.dashboard.settings;
  // Read through the user's own session: RLS guarantees only their row is visible.
  const supabase = await createSupabaseServerClient();
  const { data } = await supabase.from("notification_preferences").select("email_enabled,in_app_enabled").maybeSingle<{ email_enabled: boolean; in_app_enabled: boolean }>();
  const errCode = first(sp.error);
  return (
    <>
      <h1 className="text-2xl font-bold">{t.title}</h1>
      {errCode ? <Alert kind="error">{d.errors.generic}</Alert> : null}
      {first(sp.ok) ? <Alert kind="ok">{d.common.saved}</Alert> : null}
      <Card>
        <h2 className="font-semibold">{t.notifications}</h2>
        <form action={updateSettingsAction} className="mt-3 space-y-3">
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="email_enabled" defaultChecked={data?.email_enabled ?? true} /> {t.email}
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="in_app_enabled" defaultChecked={data?.in_app_enabled ?? true} /> {t.inApp}
          </label>
          <button className={btnCls}>{d.common.save}</button>
        </form>
      </Card>
    </>
  );
}
