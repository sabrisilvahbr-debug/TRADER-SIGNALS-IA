import { Alert, Card, btnCls, btnGhostCls, first, inputCls } from "@/components/ui";
import { SUPPORTED_ASSETS } from "@/lib/authz/plans";
import { fmt, getDictionary } from "@/i18n";
import { supabaseFavoritesRepo } from "@/server/repos";
import { requireUser } from "@/server/session";
import { addFavoriteAction, removeFavoriteAction } from "../actions";

export default async function FavoritesPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const s = await requireUser();
  const sp = await searchParams;
  const d = getDictionary(s.profile.locale);
  const f = d.dashboard.favorites;
  const items = await supabaseFavoritesRepo.list(s.auth.userId);
  const errCode = first(sp.error);

  return (
    <>
      <h1 className="text-2xl font-bold">{f.title}</h1>
      {errCode ? <Alert kind="error">{d.errors[errCode as keyof typeof d.errors] ?? d.errors.generic}</Alert> : null}
      {first(sp.ok) ? <Alert kind="ok">{d.common.saved}</Alert> : null}
      <Card>
        <p className="text-sm text-[var(--muted)]">{fmt(f.usage, { used: items.length, max: s.access.plan.maxAssets })}</p>
        {items.length === 0 ? (
          <p className="mt-3 text-sm">{f.empty}</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {items.map((sym) => (
              <li key={sym} className="flex items-center justify-between rounded border border-[var(--line)] px-3 py-2">
                <span className="font-mono">{sym}</span>
                <form action={removeFavoriteAction}>
                  <input type="hidden" name="symbol" value={sym} />
                  <button className={btnGhostCls}>{f.remove}</button>
                </form>
              </li>
            ))}
          </ul>
        )}
        <form action={addFavoriteAction} className="mt-4 flex items-end gap-3">
          <label className="text-sm font-medium">
            {f.choose}
            <select name="symbol" className={inputCls} defaultValue={SUPPORTED_ASSETS[0]}>
              {SUPPORTED_ASSETS.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </select>
          </label>
          <button className={btnCls}>{f.add}</button>
        </form>
      </Card>
    </>
  );
}
