"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireUser } from "@/server/session";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { addFavorite, removeFavorite } from "@/server/favorites/service";
import { supabaseFavoritesRepo } from "@/server/repos";
import { LOCALES, LOCALE_COOKIE } from "@/i18n";
import { isValidTimeZone } from "@/lib/timezone";

export async function addFavoriteAction(formData: FormData) {
  const s = await requireUser();
  const r = await addFavorite(supabaseFavoritesRepo, { userId: s.auth.userId, status: s.auth.status }, s.access, formData.get("symbol"));
  revalidatePath("/dashboard/favorites");
  redirect(r.ok ? "/dashboard/favorites?ok=1" : `/dashboard/favorites?error=${r.code}`);
}

export async function removeFavoriteAction(formData: FormData) {
  const s = await requireUser();
  const r = await removeFavorite(supabaseFavoritesRepo, { userId: s.auth.userId, status: s.auth.status }, formData.get("symbol"));
  revalidatePath("/dashboard/favorites");
  redirect(r.ok ? "/dashboard/favorites?ok=1" : `/dashboard/favorites?error=${r.code}`);
}

const profileSchema = z.object({
  display_name: z.string().trim().max(80).optional(),
  locale: z.enum(LOCALES),
  timezone: z.string().refine(isValidTimeZone),
});

export async function updateProfileAction(formData: FormData) {
  const s = await requireUser();
  const parsed = profileSchema.safeParse({
    display_name: String(formData.get("display_name") ?? ""),
    locale: formData.get("locale"),
    timezone: formData.get("timezone"),
  });
  if (!parsed.success) redirect("/dashboard/profile?error=invalid_input");

  // Own-row update through the user's session: RLS + column grants apply (role/status are immutable here).
  const supabase = await createSupabaseServerClient();
  const { error } = await supabase
    .from("profiles")
    .update({ display_name: parsed.data.display_name || null, locale: parsed.data.locale, timezone: parsed.data.timezone })
    .eq("id", s.auth.userId);
  if (error) redirect("/dashboard/profile?error=generic");

  (await cookies()).set(LOCALE_COOKIE, parsed.data.locale, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
  revalidatePath("/dashboard", "layout");
  redirect("/dashboard/profile?ok=1");
}

export async function updateSettingsAction(formData: FormData) {
  const s = await requireUser();
  const supabase = await createSupabaseServerClient();
  const { error } = await supabase
    .from("notification_preferences")
    .update({ email_enabled: formData.get("email_enabled") === "on", in_app_enabled: formData.get("in_app_enabled") === "on" })
    .eq("user_id", s.auth.userId);
  if (error) redirect("/dashboard/settings?error=generic");
  redirect("/dashboard/settings?ok=1");
}
