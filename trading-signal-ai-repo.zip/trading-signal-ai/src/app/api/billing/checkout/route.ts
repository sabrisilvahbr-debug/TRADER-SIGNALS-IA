import { apiDeps, json, rejectForeignOrigin } from "@/server/api-deps";
import { handleCheckout } from "@/server/billing/checkout";

export async function POST(request: Request) {
  const bad = rejectForeignOrigin(request);
  if (bad) return bad;
  const r = await handleCheckout(apiDeps());
  return json(r.status, r.body, r.headers);
}
