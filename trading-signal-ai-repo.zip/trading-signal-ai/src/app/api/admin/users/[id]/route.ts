import { apiDeps, json, rejectForeignOrigin } from "@/server/api-deps";
import { handleUserAdminAction } from "@/server/admin/user-actions";
import { supabaseUserAdminRepo } from "@/server/repos";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const bad = rejectForeignOrigin(request);
  if (bad) return bad;
  const { id } = await params;
  let body: unknown = null;
  try {
    body = await request.json();
  } catch {
    // handled by schema validation (after authorization)
  }
  const r = await handleUserAdminAction({ ...apiDeps(), repo: supabaseUserAdminRepo }, id, body);
  return json(r.status, r.body, r.headers);
}
