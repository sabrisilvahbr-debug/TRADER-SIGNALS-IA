import { apiDeps, json, rejectForeignOrigin } from "@/server/api-deps";
import { handleEnginePause } from "@/server/admin/engine-actions";
import { supabaseEngineRepo } from "@/server/repos";

export async function POST(request: Request) {
  const bad = rejectForeignOrigin(request);
  if (bad) return bad;
  let body: unknown = null;
  try {
    body = await request.json();
  } catch {
    // handled by schema validation (after authorization)
  }
  const r = await handleEnginePause({ ...apiDeps(), repo: supabaseEngineRepo }, body);
  return json(r.status, r.body, r.headers);
}
