import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";
import { Card } from "@/components/ui";
import { getPublicDictionary } from "@/server/locale";

export default async function HomePage() {
  const { d } = await getPublicDictionary();
  return (
    <PublicShell>
      <section className="py-10 text-center">
        <h1 className="mx-auto max-w-3xl text-4xl font-bold tracking-tight">{d.home.title}</h1>
        <p className="mx-auto mt-4 max-w-2xl text-lg text-[var(--muted)]">{d.home.subtitle}</p>
        <div className="mt-8 flex justify-center gap-3">
          <Link href="/signup" className="rounded-md bg-[var(--brand)] px-5 py-2.5 font-medium text-white">
            {d.home.cta}
          </Link>
          <Link href="/pricing" className="rounded-md border border-[var(--line)] px-5 py-2.5 font-medium">
            {d.home.ctaSecondary}
          </Link>
        </div>
      </section>

      <section id="features" className="py-8">
        <h2 className="mb-4 text-2xl font-semibold">{d.home.featuresTitle}</h2>
        <div className="grid gap-4 md:grid-cols-3">
          {d.home.features.map((f) => (
            <Card key={f.title}>
              <h3 className="font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm text-[var(--muted)]">{f.text}</p>
            </Card>
          ))}
        </div>
      </section>

      <section id="faq" className="py-8">
        <h2 className="mb-4 text-2xl font-semibold">{d.home.faqTitle}</h2>
        <div className="space-y-3">
          {d.home.faq.map((f) => (
            <details key={f.q} className="rounded-lg border border-[var(--line)] bg-[var(--card)] p-4">
              <summary className="cursor-pointer font-medium">{f.q}</summary>
              <p className="mt-2 text-sm text-[var(--muted)]">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="py-8">
        <Card>
          <h2 className="font-semibold">{d.home.riskTitle}</h2>
          <p className="mt-2 text-sm text-[var(--muted)]">{d.risk}</p>
        </Card>
      </section>
    </PublicShell>
  );
}
