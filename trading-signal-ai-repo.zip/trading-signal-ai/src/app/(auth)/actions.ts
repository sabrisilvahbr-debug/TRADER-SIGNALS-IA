"use server";

import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { z } from "zod";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { publicEnv } from "@/lib/env";
import { createRateLimiter } from "@/lib/rate-limit";
import { safeNextPath } from "@/lib/safe-redirect";
import { DEFAULT_LOCALE, LOCALE_COOKIE, isLocale } from "@/i18n";
import { cookies } from "next/headers";

const limiter = createRateLimiter({ limit: 10, windowMs: 60_000 });

async function clientKey(action: string): Promise<string> {
  const h = await headers();
  const ip = h.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  return `${action}:${ip}`;
}

const emailSchema = z.email().max(254);
const newPasswordSchema = z.string().min(10).max(128);

export async function signInAction(formData: FormData) {
  const next = safeNextPath(String(formData.get("next") ?? ""));
  const parsed = z.object({ email: emailSchema, password: z.string().min(1).max(128) }).safeParse({
    email: formData.get("email"),
    password: formData.get("password"),
  });
  if (!parsed.success) redirect("/login?error=invalid_input");
  if (!limiter.check(await clientKey("signin")).ok) redirect("/login?error=rate_limited");

  const supabase = await createSupabaseServerClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);
  if (error) {
    redirect(`/login?error=${error.code === "user_banned" ? "suspended" : "invalid_credentials"}`);
  }
  redirect(next);
}

export async function signUpAction(formData: FormData) {
  const parsed = z.object({ email: emailSchema, password: newPasswordSchema }).safeParse({
    email: formData.get("email"),
    password: formData.get("password"),
  });
  if (!parsed.success) redirect("/signup?error=invalid_input");
  if (!limiter.check(await clientKey("signup")).ok) redirect("/signup?error=rate_limited");

  const cookieLocale = (await cookies()).get(LOCALE_COOKIE)?.value;
  const locale = isLocale(cookieLocale) ? cookieLocale : DEFAULT_LOCALE;

  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase.auth.signUp({
    ...parsed.data,
    options: { emailRedirectTo: `${publicEnv().NEXT_PUBLIC_APP_URL}/auth/callback`, data: { locale } },
  });
  if (error) redirect("/signup?error=invalid_input");
  // E-mail confirmation disabled => session already exists.
  if (data.session) redirect("/dashboard");
  // Same message whether or not the e-mail already exists (no account enumeration).
  redirect("/signup?ok=1");
}

export async function requestPasswordResetAction(formData: FormData) {
  const parsed = emailSchema.safeParse(formData.get("email"));
  if (!parsed.success) redirect("/forgot-password?error=invalid_input");
  if (!limiter.check(await clientKey("reset")).ok) redirect("/forgot-password?error=rate_limited");

  const supabase = await createSupabaseServerClient();
  await supabase.auth.resetPasswordForEmail(parsed.data, {
    redirectTo: `${publicEnv().NEXT_PUBLIC_APP_URL}/auth/callback?next=/reset-password`,
  });
  redirect("/forgot-password?ok=1");
}

export async function updatePasswordAction(formData: FormData) {
  const parsed = newPasswordSchema.safeParse(formData.get("password"));
  if (!parsed.success) redirect("/reset-password?error=invalid_input");

  const supabase = await createSupabaseServerClient();
  const { error } = await supabase.auth.updateUser({ password: parsed.data });
  if (error) redirect("/reset-password?error=auth_failed");
  await supabase.auth.signOut();
  redirect("/login?ok=password_updated");
}

export async function signOutAction() {
  const supabase = await createSupabaseServerClient();
  await supabase.auth.signOut();
  redirect("/");
}
