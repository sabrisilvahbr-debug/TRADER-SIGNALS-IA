import { PublicShell } from "@/components/PublicShell";
import { AuthCard } from "@/components/AuthForm";
import { Field, btnCls, first, inputCls } from "@/components/ui";
import { getPublicDictionary } from "@/server/locale";
import { requestPasswordResetAction } from "../actions";

export default async function ForgotPasswordPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { d } = await getPublicDictionary();
  const errCode = first(sp.error);
  const error = errCode ? (d.errors[errCode as keyof typeof d.errors] ?? d.errors.generic) : undefined;
  const ok = first(sp.ok) ? d.auth.checkEmail : undefined;

  return (
    <PublicShell>
      <AuthCard title={d.auth.forgotTitle} error={error} ok={ok}>
        <form action={requestPasswordResetAction} className="space-y-4">
          <Field label={d.auth.email}>
            <input className={inputCls} name="email" type="email" autoComplete="email" required maxLength={254} />
          </Field>
          <button className={`${btnCls} w-full`}>{d.auth.submitForgot}</button>
        </form>
      </AuthCard>
    </PublicShell>
  );
}
