import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";
import { AuthCard } from "@/components/AuthForm";
import { Field, btnCls, first, inputCls } from "@/components/ui";
import { getPublicDictionary } from "@/server/locale";
import { signInAction } from "../actions";

export default async function LoginPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { d } = await getPublicDictionary();
  const errCode = first(sp.error);
  const error = errCode ? (d.errors[errCode as keyof typeof d.errors] ?? d.errors.generic) : undefined;
  const ok = first(sp.ok) === "password_updated" ? d.auth.passwordUpdated : undefined;

  return (
    <PublicShell>
      <AuthCard title={d.auth.loginTitle} error={error} ok={ok}>
        <form action={signInAction} className="space-y-4">
          <input type="hidden" name="next" value={first(sp.next) ?? ""} />
          <Field label={d.auth.email}>
            <input className={inputCls} name="email" type="email" autoComplete="email" required maxLength={254} />
          </Field>
          <Field label={d.auth.password}>
            <input className={inputCls} name="password" type="password" autoComplete="current-password" required maxLength={128} />
          </Field>
          <button className={`${btnCls} w-full`}>{d.auth.submitLogin}</button>
        </form>
        <p className="text-sm">
          <Link href="/forgot-password" className="underline">
            {d.auth.forgotLink}
          </Link>
        </p>
        <p className="text-sm text-[var(--muted)]">
          {d.auth.noAccount}{" "}
          <Link href="/signup" className="underline">
            {d.nav.signup}
          </Link>
        </p>
      </AuthCard>
    </PublicShell>
  );
}
