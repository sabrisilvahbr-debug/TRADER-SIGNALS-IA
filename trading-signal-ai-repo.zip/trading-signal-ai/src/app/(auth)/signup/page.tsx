import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";
import { AuthCard } from "@/components/AuthForm";
import { Field, btnCls, first, inputCls } from "@/components/ui";
import { getPublicDictionary } from "@/server/locale";
import { signUpAction } from "../actions";

export default async function SignupPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { d } = await getPublicDictionary();
  const errCode = first(sp.error);
  const error = errCode ? (d.errors[errCode as keyof typeof d.errors] ?? d.errors.generic) : undefined;
  const ok = first(sp.ok) ? d.auth.checkEmail : undefined;

  return (
    <PublicShell>
      <AuthCard title={d.auth.signupTitle} error={error} ok={ok}>
        <form action={signUpAction} className="space-y-4">
          <Field label={d.auth.email}>
            <input className={inputCls} name="email" type="email" autoComplete="email" required maxLength={254} />
          </Field>
          <Field label={d.auth.password} hint={d.auth.passwordHint}>
            <input className={inputCls} name="password" type="password" autoComplete="new-password" required minLength={10} maxLength={128} />
          </Field>
          <button className={`${btnCls} w-full`}>{d.auth.submitSignup}</button>
        </form>
        <p className="text-xs text-[var(--muted)]">{d.risk}</p>
        <p className="text-sm text-[var(--muted)]">
          {d.auth.haveAccount}{" "}
          <Link href="/login" className="underline">
            {d.nav.login}
          </Link>
        </p>
      </AuthCard>
    </PublicShell>
  );
}
