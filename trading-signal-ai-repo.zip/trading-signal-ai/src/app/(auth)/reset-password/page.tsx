import { PublicShell } from "@/components/PublicShell";
import { AuthCard } from "@/components/AuthForm";
import { Field, btnCls, first, inputCls } from "@/components/ui";
import { getPublicDictionary } from "@/server/locale";
import { updatePasswordAction } from "../actions";

export default async function ResetPasswordPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { d } = await getPublicDictionary();
  const errCode = first(sp.error);
  const error = errCode ? (d.errors[errCode as keyof typeof d.errors] ?? d.errors.generic) : undefined;

  return (
    <PublicShell>
      <AuthCard title={d.auth.resetTitle} error={error}>
        <form action={updatePasswordAction} className="space-y-4">
          <Field label={d.auth.newPassword} hint={d.auth.passwordHint}>
            <input className={inputCls} name="password" type="password" autoComplete="new-password" required minLength={10} maxLength={128} />
          </Field>
          <button className={`${btnCls} w-full`}>{d.auth.submitReset}</button>
        </form>
      </AuthCard>
    </PublicShell>
  );
}
