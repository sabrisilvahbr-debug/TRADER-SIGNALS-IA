import { notFound } from "next/navigation";
import { PublicShell } from "@/components/PublicShell";
import { Alert } from "@/components/ui";
import { getPublicDictionary } from "@/server/locale";

export default async function LegalPage({ params }: { params: Promise<{ doc: string }> }) {
  const { doc } = await params;
  const { d } = await getPublicDictionary();
  if (doc !== "terms" && doc !== "privacy" && doc !== "risk") notFound();
  const content = d.legal.docs[doc];
  return (
    <PublicShell>
      <h1 className="text-3xl font-bold">{content.title}</h1>
      <div className="mt-4">
        <Alert kind="warn">{d.legal.draft}</Alert>
      </div>
      <p className="mt-6 max-w-2xl">{content.text}</p>
    </PublicShell>
  );
}
