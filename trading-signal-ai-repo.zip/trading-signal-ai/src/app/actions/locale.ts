"use server";

import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { LOCALE_COOKIE, isLocale } from "@/i18n";
import { getAuthContext } from "@/server/session";
import { createAdminClient } from "@/lib/supabase/admin";
import { safeNextPath } from "@/lib/safe-redirect";

export async function setLocaleAction(formData: FormData) {
  const locale = formData.get("locale");
  if (!isLocale(locale)) redirect("/");

  (await cookies()).set(LOCALE_COOKIE, locale, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });

  // Signed-in users also persist the preference in their profile (own id, from the session).
  const ctx = await getAuthContext().catch(() => null);
  if (ctx) await createAdminClient().from("profiles").update({ locale }).eq("id", ctx.auth.userId);

  let back = "/";
  const referer = (await headers()).get("referer");
  if (referer) {
    try {
      const u = new URL(referer);
      back = safeNextPath(u.pathname + u.search, "/");
    } catch {
      back = "/";
    }
  }
  redirect(back);
}
