import ptBR, { type Dictionary } from "./pt-BR";
import en from "./en";

export const LOCALES = ["pt-BR", "en"] as const;
export type Locale = (typeof LOCALES)[number];
export const DEFAULT_LOCALE: Locale = "pt-BR";
export const LOCALE_COOKIE = "tsai_locale";

const dictionaries: Record<Locale, Dictionary> = { "pt-BR": ptBR, en };

export function isLocale(v: unknown): v is Locale {
  return typeof v === "string" && (LOCALES as readonly string[]).includes(v);
}
export function getDictionary(locale: Locale): Dictionary {
  return dictionaries[locale];
}
/** Replaces `{name}` placeholders. */
export function fmt(template: string, vars: Record<string, string | number>): string {
  return template.replace(/\{(\w+)\}/g, (_, k: string) => String(vars[k] ?? ""));
}
export type { Dictionary };
