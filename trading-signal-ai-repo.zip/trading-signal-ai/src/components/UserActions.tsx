"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { GRANTABLE_PERMISSIONS, type GrantablePermission } from "@/lib/authz/types";

interface Labels {
  suspend: string;
  reactivate: string;
  confirmSuspend: string;
  confirmReactivate: string;
  roleLabel: string;
  grants: string;
  saveRole: string;
  confirmRole: string;
  protected: string;
  done: string;
  failed: string;
  roles: { admin: string; user: string };
  grantNames: Record<GrantablePermission, string>;
}

export function UserActions(props: {
  target: { id: string; role: "owner" | "admin" | "user"; status: "active" | "suspended"; grants: GrantablePermission[] };
  viewer: { isOwner: boolean; canSuspend: boolean; isSelf: boolean };
  labels: Labels;
}) {
  const { target, viewer, labels } = props;
  const router = useRouter();
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [role, setRole] = useState<"admin" | "user">(target.role === "admin" ? "admin" : "user");
  const [grants, setGrants] = useState<GrantablePermission[]>(target.grants);

  // UI hints only. The API re-checks everything on the server.
  const untouchable = target.role === "owner" || viewer.isSelf;
  const adminCannotManage = !viewer.isOwner && target.role !== "user";
  if (untouchable || adminCannotManage) return <span className="text-xs text-[var(--muted)]">{labels.protected}</span>;

  async function send(body: Record<string, unknown>, confirmText: string) {
    if (!window.confirm(confirmText)) return;
    setBusy(true);
    setMsg(null);
    try {
      const res = await fetch(`/api/admin/users/${target.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...body, confirm: true }),
      });
      setMsg({ ok: res.ok, text: res.ok ? labels.done : labels.failed });
      if (res.ok) router.refresh();
    } catch {
      setMsg({ ok: false, text: labels.failed });
    } finally {
      setBusy(false);
    }
  }

  const btn = "rounded border border-[var(--line)] px-2 py-1 text-xs hover:bg-black/5 disabled:opacity-50";
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2">
        {viewer.canSuspend &&
          (target.status === "active" ? (
            <button className={btn} disabled={busy} onClick={() => send({ action: "suspend" }, labels.confirmSuspend)}>
              {labels.suspend}
            </button>
          ) : (
            <button className={btn} disabled={busy} onClick={() => send({ action: "reactivate" }, labels.confirmReactivate)}>
              {labels.reactivate}
            </button>
          ))}
      </div>

      {viewer.isOwner ? (
        <details className="text-xs">
          <summary className="cursor-pointer">{labels.roleLabel}</summary>
          <div className="mt-2 space-y-2">
            <select aria-label={labels.roleLabel} className="rounded border border-[var(--line)] bg-[var(--card)] px-2 py-1" value={role} onChange={(e) => setRole(e.target.value as "admin" | "user")}>
              <option value="user">{labels.roles.user}</option>
              <option value="admin">{labels.roles.admin}</option>
            </select>
            {role === "admin" ? (
              <fieldset className="space-y-1">
                <legend className="font-medium">{labels.grants}</legend>
                {GRANTABLE_PERMISSIONS.map((p) => (
                  <label key={p} className="flex items-center gap-2">
                    <input type="checkbox" checked={grants.includes(p)} onChange={(e) => setGrants(e.target.checked ? [...grants, p] : grants.filter((g) => g !== p))} />
                    {labels.grantNames[p]}
                  </label>
                ))}
              </fieldset>
            ) : null}
            <button
              className={btn}
              disabled={busy}
              onClick={async () => {
                if (!window.confirm(labels.confirmRole)) return;
                setBusy(true);
                setMsg(null);
                try {
                  const call = (body: Record<string, unknown>) =>
                    fetch(`/api/admin/users/${target.id}`, {
                      method: "PATCH",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ ...body, confirm: true }),
                    });
                  let ok = true;
                  if (role !== target.role) ok = (await call({ action: "set_role", role })).ok;
                  if (ok && role === "admin") ok = (await call({ action: "set_grants", grants })).ok;
                  setMsg({ ok, text: ok ? labels.done : labels.failed });
                  if (ok) router.refresh();
                } catch {
                  setMsg({ ok: false, text: labels.failed });
                } finally {
                  setBusy(false);
                }
              }}
            >
              {labels.saveRole}
            </button>
          </div>
        </details>
      ) : null}

      {msg ? (
        <p role="status" className={`text-xs ${msg.ok ? "text-green-700" : "text-red-700"}`}>
          {msg.text}
        </p>
      ) : null}
    </div>
  );
}
