import Link from "next/link";
import type { ReactNode } from "react";
import { getPublicDictionary } from "@/server/locale";
import { LocaleSwitcher } from "./LocaleSwitcher";

export async function PublicShell({ children }: { children: ReactNode }) {
  const { locale, d } = await getPublicDictionary();
  return (
    <>
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:bg-[var(--card)] focus:p-2">
        {d.common.skipToContent}
      </a>
      <header className="border-b border-[var(--line)]">
        <nav className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-3" aria-label="Main">
          <Link href="/" className="font-bold">
            {d.common.appName}
          </Link>
          <div className="flex flex-wrap items-center gap-4 text-sm">
            <Link href="/#features">{d.nav.features}</Link>
            <Link href="/pricing">{d.nav.pricing}</Link>
            <Link href="/#faq">{d.nav.faq}</Link>
            <Link href="/login">{d.nav.login}</Link>
            <Link href="/signup" className="rounded-md bg-[var(--brand)] px-3 py-1.5 font-medium text-white">
              {d.nav.signup}
            </Link>
            <LocaleSwitcher current={locale} label={d.common.language} />
          </div>
        </nav>
      </header>
      <main id="main" className="mx-auto max-w-5xl px-4 py-10">
        {children}
      </main>
      <footer className="border-t border-[var(--line)] py-6 text-xs text-[var(--muted)]">
        <div className="mx-auto max-w-5xl space-y-2 px-4">
          <p>{d.risk}</p>
          <p className="flex gap-4">
            <Link href="/legal/terms">{d.legal.footer.terms}</Link>
            <Link href="/legal/privacy">{d.legal.footer.privacy}</Link>
            <Link href="/legal/risk">{d.legal.footer.risk}</Link>
          </p>
        </div>
      </footer>
    </>
  );
}
