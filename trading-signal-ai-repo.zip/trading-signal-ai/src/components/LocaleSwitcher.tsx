import { setLocaleAction } from "@/app/actions/locale";
import { LOCALES, type Locale } from "@/i18n";

const LABELS: Record<Locale, string> = { "pt-BR": "PT", en: "EN" };

export function LocaleSwitcher({ current, label }: { current: Locale; label: string }) {
  return (
    <form action={setLocaleAction} className="flex items-center gap-1" aria-label={label}>
      {LOCALES.map((l) => (
        <button
          key={l}
          name="locale"
          value={l}
          aria-pressed={l === current}
          className={`rounded px-2 py-1 text-xs font-semibold ${l === current ? "bg-[var(--brand)] text-white" : "border border-[var(--line)]"}`}
        >
          {LABELS[l]}
        </button>
      ))}
    </form>
  );
}
