"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { btnCls } from "./ui";

export function EnginePause({
  paused,
  labels,
}: {
  paused: boolean;
  labels: { pause: string; resume: string; confirmPause: string; confirmResume: string; failed: string };
}) {
  const router = useRouter();
  const [error, setError] = useState(false);
  async function toggle() {
    if (!window.confirm(paused ? labels.confirmResume : labels.confirmPause)) return;
    setError(false);
    const res = await fetch("/api/admin/engine", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ paused: !paused, confirm: true }),
    }).catch(() => null);
    if (res?.ok) router.refresh();
    else setError(true);
  }
  return (
    <div className="space-y-2">
      <button className={btnCls} onClick={() => void toggle()}>
        {paused ? labels.resume : labels.pause}
      </button>
      {error ? <p role="alert" className="text-sm text-red-600">{labels.failed}</p> : null}
    </div>
  );
}
