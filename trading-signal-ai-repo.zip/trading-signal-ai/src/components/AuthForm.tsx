import type { ReactNode } from "react";
import { Alert, Card } from "./ui";

export function AuthCard({ title, error, ok, children }: { title: string; error?: string; ok?: string; children: ReactNode }) {
  return (
    <div className="mx-auto max-w-md">
      <Card>
        <h1 className="mb-4 text-2xl font-bold">{title}</h1>
        <div className="space-y-4">
          {error ? <Alert kind="error">{error}</Alert> : null}
          {ok ? <Alert kind="ok">{ok}</Alert> : null}
          {children}
        </div>
      </Card>
    </div>
  );
}
