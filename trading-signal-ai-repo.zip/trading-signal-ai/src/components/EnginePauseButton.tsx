"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function EnginePauseButton({ paused, labels }: { paused: boolean; labels: { pause: string; resume: string; confirmPause: string; confirmResume: string; failed: string } }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(false);

  async function toggle() {
    if (!window.confirm(paused ? labels.confirmResume : labels.confirmPause)) return;
    setBusy(true);
    setError(false);
    try {
      const res = await fetch("/api/admin/engine", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paused: !paused, confirm: true }),
      });
      if (res.ok) router.refresh();
      else setError(true);
    } catch {
      setError(true);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-2">
      <button onClick={toggle} disabled={busy} className="rounded-md bg-[var(--brand)] px-4 py-2 text-sm font-medium text-white disabled:opacity-50">
        {paused ? labels.resume : labels.pause}
      </button>
      {error ? (
        <p role="alert" className="text-sm text-red-700">
          {labels.failed}
        </p>
      ) : null}
    </div>
  );
}
