import type { ReactNode } from "react";

export const inputCls =
  "mt-1 block w-full rounded-md border border-[var(--line)] bg-[var(--card)] px-3 py-2 text-sm text-[var(--fg)]";
export const btnCls =
  "inline-flex items-center justify-center rounded-md bg-[var(--brand)] px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50";
export const btnGhostCls =
  "inline-flex items-center justify-center rounded-md border border-[var(--line)] px-3 py-1.5 text-sm hover:bg-black/5";

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-lg border border-[var(--line)] bg-[var(--card)] p-5 ${className}`}>{children}</section>;
}

export function Alert({ kind, children }: { kind: "error" | "ok" | "warn"; children: ReactNode }) {
  const tone =
    kind === "error"
      ? "border-red-400 bg-red-50 text-red-900 dark:bg-red-950 dark:text-red-100"
      : kind === "ok"
        ? "border-green-400 bg-green-50 text-green-900 dark:bg-green-950 dark:text-green-100"
        : "border-amber-400 bg-amber-50 text-amber-900 dark:bg-amber-950 dark:text-amber-100";
  return (
    <div role={kind === "error" ? "alert" : "status"} className={`rounded-md border px-4 py-3 text-sm ${tone}`}>
      {children}
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block text-sm font-medium">
      {label}
      {children}
      {hint ? <span className="mt-1 block text-xs font-normal text-[var(--muted)]">{hint}</span> : null}
    </label>
  );
}

export function first(v: string | string[] | undefined): string | undefined {
  return Array.isArray(v) ? v[0] : v;
}
