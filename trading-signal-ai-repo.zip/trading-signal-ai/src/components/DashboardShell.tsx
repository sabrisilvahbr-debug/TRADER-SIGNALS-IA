import Link from "next/link";
import type { ReactNode } from "react";
import { signOutAction } from "@/app/(auth)/actions";
import { canAccessAdmin } from "@/lib/authz/permissions";
import { getDictionary } from "@/i18n";
import type { Session } from "@/server/session";
import { LocaleSwitcher } from "./LocaleSwitcher";

const ITEMS = [
  ["overview", "/dashboard"],
  ["market", "/dashboard/market"],
  ["charts", "/dashboard/charts"],
  ["signals", "/dashboard/signals"],
  ["history", "/dashboard/history"],
  ["stats", "/dashboard/stats"],
  ["favorites", "/dashboard/favorites"],
  ["alerts", "/dashboard/alerts"],
  ["subscription", "/dashboard/subscription"],
  ["profile", "/dashboard/profile"],
  ["settings", "/dashboard/settings"],
] as const;

export function planBadge(session: Session, d: ReturnType<typeof getDictionary>): string {
  return session.access.label === "OWNER" ? d.plan.ownerLabel : d.plan.names[session.access.label];
}

export function DashboardShell({ session, children }: { session: Session; children: ReactNode }) {
  const d = getDictionary(session.profile.locale);
  return (
    <div className="min-h-screen md:flex">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:bg-[var(--card)] focus:p-2">
        {d.common.skipToContent}
      </a>
      <aside className="border-b border-[var(--line)] p-4 md:w-60 md:border-b-0 md:border-r">
        <Link href="/dashboard" className="block text-lg font-bold">
          {d.common.appName}
        </Link>
        <nav aria-label="Dashboard" className="mt-4 flex flex-wrap gap-x-4 gap-y-1 text-sm md:flex-col md:gap-1">
          {ITEMS.map(([key, href]) => (
            <Link key={key} href={href} className="rounded px-2 py-1 hover:bg-black/5">
              {d.dashboard.nav[key]}
            </Link>
          ))}
          {canAccessAdmin(session.auth) ? (
            <Link href="/admin" className="rounded px-2 py-1 font-semibold hover:bg-black/5">
              {d.dashboard.nav.admin}
            </Link>
          ) : null}
        </nav>
      </aside>
      <div className="flex-1">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--line)] px-4 py-3 text-sm">
          <span className="rounded-full border border-[var(--line)] px-3 py-1 font-semibold">{planBadge(session, d)}</span>
          <div className="flex items-center gap-3">
            <span className="text-[var(--muted)]">{session.profile.email}</span>
            <LocaleSwitcher current={session.profile.locale} label={d.common.language} />
            <form action={signOutAction}>
              <button className="underline">{d.common.signOut}</button>
            </form>
          </div>
        </header>
        <main id="main" className="mx-auto max-w-4xl space-y-6 px-4 py-8">
          {children}
          <p className="border-t border-[var(--line)] pt-4 text-xs text-[var(--muted)]">{d.risk}</p>
        </main>
      </div>
    </div>
  );
}
