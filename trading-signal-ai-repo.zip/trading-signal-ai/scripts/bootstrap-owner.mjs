// Inicializa a conta OWNER de forma segura e idempotente.
// Uso: npm run bootstrap-owner   (le .env.local; nunca imprime segredos)
import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
const email = process.env.INITIAL_OWNER_EMAIL?.trim();

if (!url || !key || !email) {
  console.error("Defina NEXT_PUBLIC_SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY e INITIAL_OWNER_EMAIL em .env.local.");
  process.exit(1);
}

const messages = {
  owner_assigned: "OK: papel OWNER atribuido.",
  already_owner: "OK: a conta ja e OWNER (nada a fazer).",
  user_not_found: "ERRO: nenhuma conta com esse e-mail. Crie a conta em /signup e confirme o e-mail primeiro.",
  email_not_confirmed: "ERRO: o e-mail da conta ainda nao foi confirmado. Confirme-o e rode de novo.",
  owner_already_assigned_to_other_user: "ERRO: ja existe outro OWNER. Troca de proprietario exige migracao manual.",
  invalid_email: "ERRO: INITIAL_OWNER_EMAIL invalido.",
  profile_missing: "ERRO: perfil nao encontrado para a conta. Verifique as migracoes.",
};

const db = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
const { data, error } = await db.rpc("bootstrap_owner", { p_email: email });
if (error) {
  console.error(`ERRO ao chamar bootstrap_owner (${error.code ?? "sem codigo"}). Migracoes aplicadas?`);
  process.exit(1);
}
console.log(messages[data] ?? `Resultado inesperado: ${data}`);
process.exit(data === "owner_assigned" || data === "already_owner" ? 0 : 2);
