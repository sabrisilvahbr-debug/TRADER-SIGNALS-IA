-- Trading Signal AI :: migration 1/3 :: core schema
-- Papel de sistema (owner/admin/user) e INDEPENDENTE do plano comercial (free/pro/premium).

create type public.app_role as enum ('owner', 'admin', 'user');
create type public.account_status as enum ('active', 'suspended');

create function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------------------------------------------------------------- profiles
create table public.profiles (
  id           uuid primary key references auth.users (id) on delete cascade,
  email        text not null,
  display_name text check (display_name is null or char_length(display_name) <= 80),
  locale       text not null default 'pt-BR' check (locale in ('pt-BR', 'en')),
  timezone     text not null default 'America/Sao_Paulo' check (char_length(timezone) between 1 and 64),
  role         public.app_role not null default 'user',
  status       public.account_status not null default 'active',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
-- No maximo UM proprietario no sistema.
create unique index profiles_single_owner on public.profiles ((true)) where role = 'owner';
create index profiles_email_lower_idx on public.profiles (lower(email));
create index profiles_created_at_idx on public.profiles (created_at desc);
create trigger profiles_set_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

-- ------------------------------------------------------------------- plans
-- Fonte de verdade dos limites comerciais. Valores abaixo sao DE DESENVOLVIMENTO,
-- nao sao promessas comerciais. Planos pagos nascem NAO publicados e sem precos:
-- precos reais exigem aprovacao do proprietario antes de cobrar clientes.
create table public.plans (
  key                  text primary key check (key in ('free', 'pro', 'premium')),
  name                 text not null,
  price_monthly_cents  integer check (price_monthly_cents is null or price_monthly_cents >= 0),
  price_yearly_cents   integer check (price_yearly_cents is null or price_yearly_cents >= 0),
  currency             text check (currency is null or currency ~ '^[a-z]{3}$'),
  max_assets           integer not null check (max_assets >= 0),
  timeframes           text[] not null default '{}',
  history_days         integer not null check (history_days >= 0),
  features             text[] not null default '{}',
  published            boolean not null default false,
  stripe_price_monthly text,
  stripe_price_yearly  text,
  sort_order           integer not null default 0,
  updated_at           timestamptz not null default now()
);
create trigger plans_set_updated_at before update on public.plans
  for each row execute function public.set_updated_at();

insert into public.plans (key, name, max_assets, timeframes, history_days, features, published, sort_order) values
  ('free',    'Free',    1,  '{1h,4h}',              7,   '{signal_feed_limited}',                                          true,  1),
  ('pro',     'Pro',     2,  '{15m,1h,4h}',          30,  '{signal_feed,filters,stats}',                                    false, 2),
  ('premium', 'Premium', 10, '{1m,5m,15m,1h,4h}',    365, '{signal_feed,filters,stats,extra_alerts,advanced_analytics}',    false, 3);

-- ----------------------------------------------------------- subscriptions
-- Preenchida SOMENTE pelo backend (webhooks Stripe, fase 9). Usuario so le a propria linha.
create table public.subscriptions (
  id                     uuid primary key default gen_random_uuid(),
  user_id                uuid not null references public.profiles (id) on delete cascade,
  stripe_customer_id     text not null,
  stripe_subscription_id text unique,
  stripe_price_id        text,
  plan_key               text not null references public.plans (key),
  status                 text not null check (status in
    ('incomplete', 'incomplete_expired', 'trialing', 'active', 'past_due', 'canceled', 'unpaid', 'paused')),
  current_period_end     timestamptz,
  cancel_at_period_end   boolean not null default false,
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now()
);
create index subscriptions_user_idx on public.subscriptions (user_id);
create index subscriptions_status_idx on public.subscriptions (status);
create trigger subscriptions_set_updated_at before update on public.subscriptions
  for each row execute function public.set_updated_at();

-- --------------------------------------------------------- user-owned data
create table public.user_favorites (
  user_id    uuid not null references public.profiles (id) on delete cascade,
  symbol     text not null check (symbol ~ '^[A-Z0-9]{5,20}$'),
  created_at timestamptz not null default now(),
  primary key (user_id, symbol)
);

create table public.notification_preferences (
  user_id        uuid primary key references public.profiles (id) on delete cascade,
  email_enabled  boolean not null default true,
  in_app_enabled boolean not null default true,
  updated_at     timestamptz not null default now()
);
create trigger notification_preferences_set_updated_at before update on public.notification_preferences
  for each row execute function public.set_updated_at();

-- ------------------------------------------------------------ admin grants
-- Permissoes explicitas do papel ADMIN. OWNER tem todas implicitamente.
-- 'roles.manage' nao e concedivel: pertence somente ao OWNER.
create table public.admin_grants (
  user_id    uuid not null references public.profiles (id) on delete cascade,
  permission text not null check (permission in
    ('users.read', 'users.suspend', 'billing.read', 'plans.read', 'engine.read', 'engine.pause', 'audit.read')),
  granted_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  primary key (user_id, permission)
);

-- -------------------------------------------------------------- audit logs
-- Append-only. Nao registrar credenciais nem dados sensiveis desnecessarios.
create table public.audit_logs (
  id          bigint generated always as identity primary key,
  created_at  timestamptz not null default now(),
  actor_id    uuid,                       -- sem FK: o log sobrevive a remocao do usuario
  actor_role  public.app_role,
  action      text not null,
  target_type text,
  target_id   text,
  result      text not null check (result in ('success', 'denied', 'error')),
  metadata    jsonb not null default '{}'::jsonb
);
create index audit_logs_created_idx on public.audit_logs (created_at desc);
create index audit_logs_actor_idx on public.audit_logs (actor_id, created_at desc);
create index audit_logs_action_idx on public.audit_logs (action, created_at desc);

create function public.audit_logs_immutable() returns trigger
language plpgsql as $$
begin
  raise exception 'audit_logs is append-only' using errcode = '42501';
end $$;
create trigger audit_logs_no_update_delete before update or delete on public.audit_logs
  for each row execute function public.audit_logs_immutable();
create trigger audit_logs_no_truncate before truncate on public.audit_logs
  for each statement execute function public.audit_logs_immutable();

-- ------------------------------------------------------------ system flags
create table public.system_flags (
  key        text primary key,
  value      jsonb not null,
  updated_by uuid references public.profiles (id) on delete set null,
  updated_at timestamptz not null default now()
);
insert into public.system_flags (key, value) values ('signals_paused', '{"paused": false}');

-- ------------------------------------------- auth.users -> profiles (sync)
-- O papel NUNCA vem de metadados do usuario (raw_user_meta_data e editavel por ele).
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_locale text := coalesce(new.raw_user_meta_data ->> 'locale', 'pt-BR');
begin
  if v_locale not in ('pt-BR', 'en') then
    v_locale := 'pt-BR';
  end if;
  insert into public.profiles (id, email, locale) values (new.id, coalesce(new.email, ''), v_locale);
  insert into public.notification_preferences (user_id) values (new.id);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create function public.handle_user_email_change() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  update public.profiles set email = coalesce(new.email, '') where id = new.id;
  return new;
end $$;
create trigger on_auth_user_email_changed after update of email on auth.users
  for each row when (old.email is distinct from new.email)
  execute function public.handle_user_email_change();
