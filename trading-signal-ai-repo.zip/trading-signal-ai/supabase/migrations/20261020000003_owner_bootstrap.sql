-- Trading Signal AI :: migration 3/3 :: inicializacao segura do OWNER
--
-- Chamada somente pelo servidor (service_role), via `npm run bootstrap-owner`.
-- Regras: a conta precisa existir no Supabase Auth E ter o e-mail CONFIRMADO; idempotente;
-- no maximo um OWNER; toda decisao fica em audit_logs.
create function public.bootstrap_owner(p_email text) returns text
language plpgsql security definer set search_path = public, auth, pg_temp as $$
declare
  v_email    text := lower(trim(coalesce(p_email, '')));
  v_user     auth.users%rowtype;
  v_existing uuid;
begin
  if v_email = '' or position('@' in v_email) = 0 then
    return 'invalid_email';
  end if;

  select * into v_user from auth.users where lower(email) = v_email limit 1;
  if not found then
    return 'user_not_found';
  end if;

  if v_user.email_confirmed_at is null then
    insert into public.audit_logs (action, target_type, target_id, result, metadata)
    values ('owner.bootstrap', 'profile', v_user.id::text, 'denied', '{"reason":"email_not_confirmed"}');
    return 'email_not_confirmed';
  end if;

  select id into v_existing from public.profiles where role = 'owner';
  if v_existing is not null and v_existing <> v_user.id then
    insert into public.audit_logs (action, target_type, target_id, result, metadata)
    values ('owner.bootstrap', 'profile', v_user.id::text, 'denied', '{"reason":"owner_already_assigned"}');
    return 'owner_already_assigned_to_other_user';
  end if;
  if v_existing = v_user.id then
    return 'already_owner';
  end if;

  update public.profiles set role = 'owner', status = 'active' where id = v_user.id;
  if not found then
    return 'profile_missing';
  end if;
  -- grants de ADMIN deixam de fazer sentido para o OWNER
  delete from public.admin_grants where user_id = v_user.id;

  insert into public.audit_logs (actor_role, action, target_type, target_id, result, metadata)
  values ('owner', 'owner.bootstrap', 'profile', v_user.id::text, 'success', '{}');
  return 'owner_assigned';
end $$;

revoke all on function public.bootstrap_owner(text) from public, anon, authenticated;
grant execute on function public.bootstrap_owner(text) to service_role;
