-- Trading Signal AI :: migration 2/3 :: grants minimos, RLS e protecao de colunas privilegiadas

-- O Supabase concede privilegios amplos a anon/authenticated por padrao. Revogamos tudo
-- e concedemos explicitamente apenas o necessario.
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon, authenticated;
alter default privileges in schema public revoke all on tables from anon, authenticated;
alter default privileges in schema public revoke all on sequences from anon, authenticated;
alter default privileges in schema public revoke execute on functions from public, anon, authenticated;

alter table public.profiles                 enable row level security;
alter table public.plans                    enable row level security;
alter table public.subscriptions            enable row level security;
alter table public.user_favorites           enable row level security;
alter table public.notification_preferences enable row level security;
alter table public.admin_grants             enable row level security;
alter table public.audit_logs               enable row level security;
alter table public.system_flags             enable row level security;

-- profiles: le a propria linha; altera SOMENTE colunas nao privilegiadas.
grant select on public.profiles to authenticated;
grant update (display_name, locale, timezone) on public.profiles to authenticated;
create policy profiles_select_own on public.profiles
  for select to authenticated using (id = (select auth.uid()));
create policy profiles_update_own on public.profiles
  for update to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()));

-- subscriptions: somente leitura da propria linha. Escrita: apenas backend (service_role).
grant select on public.subscriptions to authenticated;
create policy subscriptions_select_own on public.subscriptions
  for select to authenticated using (user_id = (select auth.uid()));

-- user_favorites: somente leitura direta. Escrita passa pelo servidor, que aplica os
-- limites do plano (um INSERT direto via API do Supabase contornaria o limite).
grant select on public.user_favorites to authenticated;
create policy user_favorites_select_own on public.user_favorites
  for select to authenticated using (user_id = (select auth.uid()));

-- notification_preferences: preferencias inofensivas, o proprio usuario edita. A linha e
-- criada no cadastro (trigger), entao nao ha INSERT direto.
grant select, update (email_enabled, in_app_enabled) on public.notification_preferences to authenticated;
create policy notification_preferences_select_own on public.notification_preferences
  for select to authenticated using (user_id = (select auth.uid()));
create policy notification_preferences_update_own on public.notification_preferences
  for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- plans, admin_grants, audit_logs, system_flags: RLS ligada, sem grants e sem policies
-- para anon/authenticated = acesso negado. Somente o servidor (service_role) acessa.

-- service_role (somente servidor): acesso total as tabelas.
grant usage on schema public to service_role;
grant all on all tables in schema public to service_role;
grant usage, select on all sequences in schema public to service_role;

-- --------------------------------------------------------------------------
-- Defesa em profundidade: colunas privilegiadas de profiles.
-- * anon/authenticated nunca alteram role/status/email/id (alem do revoke de coluna).
-- * O papel OWNER so muda pelo bootstrap controlado (funcao SECURITY DEFINER do dono da
--   migracao) ou por migracao. Nem service_role (webhooks etc.) consegue promover,
--   rebaixar ou suspender o OWNER.
create function public.guard_profile_privileged_columns() returns trigger
language plpgsql as $$
begin
  if new.id is distinct from old.id then
    raise exception 'profiles.id is immutable' using errcode = '42501';
  end if;

  if (new.role is distinct from old.role
      or new.status is distinct from old.status
      or new.email is distinct from old.email)
     and current_user in ('anon', 'authenticated') then
    raise exception 'privileged profile columns can only be changed by the server' using errcode = '42501';
  end if;

  if ((old.role = 'owner' and (new.role <> 'owner' or new.status <> 'active'))
      or (new.role = 'owner' and old.role <> 'owner'))
     and current_user not in ('postgres', 'supabase_admin') then
    raise exception 'the OWNER role is protected' using errcode = '42501';
  end if;

  return new;
end $$;
create trigger profiles_guard_privileged before update on public.profiles
  for each row execute function public.guard_profile_privileged_columns();
