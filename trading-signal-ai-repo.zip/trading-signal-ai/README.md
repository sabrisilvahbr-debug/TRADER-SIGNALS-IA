# Trading Signal AI (MicroSaaS)

Plataforma de sinais tecnicos de criptomoedas (informativa, **nao executa ordens**), multiusuario e bilingue (pt-BR / en).
Este repositorio contem a **fatia vertical 1**: autenticacao, papeis OWNER/ADMIN/USER, area do cliente, painel `/admin`,
banco com RLS e testes.

## Estado real (leia primeiro)

| Item | Estado |
|---|---|
| Cadastro, login, logout, recuperacao de senha (Supabase Auth) | Implementado; **nao testado contra um projeto Supabase real** |
| Papeis OWNER / ADMIN / USER, isolamento entre usuarios, RLS | Implementado e **testado** (Postgres em memoria emulando os papeis do Supabase) |
| Isencao de cobranca do OWNER (backend) | Implementada e testada em nivel de funcao/handler |
| Painel `/admin` (visao geral, usuarios, assinaturas, planos, motor, auditoria) | Implementado; build verificado; **nao exercitado com dados reais nem em navegador** |
| Dashboard bilingue (visao geral, favoritos, assinatura, perfil, configuracoes) | Implementado; demais secoes mostram estado vazio honesto |
| Limites de plano no backend (ex.: limite de ativos favoritos) | Implementado e testado |
| Stripe (Checkout, portal, webhooks) | **Nao implementado.** So existe o guard (OWNER nunca vai ao Checkout) e a tabela `subscriptions` |
| Dados de mercado, worker, motor de sinais, backtesting | **Nao implementado** (fases 5-8) |
| Testes E2E (Playwright), CSP, rate limit compartilhado, ESLint | **Pendentes** |
| Deploy | **Nao realizado** |

Nenhum dado e simulado: onde ainda nao ha motor ou cobranca, a interface diz isso.

## Stack
Next.js (App Router) + React + TypeScript strict, Tailwind CSS 4, Supabase (Postgres + Auth), Zod, Vitest, PGlite (testes de banco).

## Rodando localmente
```bash
npm install
cp .env.example .env.local     # preencha com as chaves do SEU projeto Supabase de desenvolvimento
# aplique supabase/migrations/*.sql no projeto (supabase db push, ou SQL Editor, em ordem)
npm run dev
npm run check                  # typecheck + testes
```

## Arquitetura de acesso
- **Identidade**: `supabase.auth.getUser()` (validado pelo Supabase Auth). Nunca cookies soltos, localStorage ou campos do cliente.
- **Papel e plano sao conceitos separados.** Papel (`profiles.role`: owner/admin/user) controla administracao; plano (free/pro/premium) controla recursos.
- **OWNER**: acesso permanente a todos os recursos (limites do PREMIUM), sem Checkout, sem Customer Stripe, sem assinatura. Decidido em `resolveEffectiveAccess` (`src/lib/authz/plans.ts`) e em `decideCheckout`.
- **ADMIN**: so executa o que o OWNER concedeu em `admin_grants`. `roles.manage` nunca e concedivel.
- **Limites de plano**: tabela `plans` (fonte central). Falha de leitura => plano restrito (fail closed).
- **Autorizacao**: `requireAdmin()` nas paginas e handlers puros em `src/server/admin/*` nas APIs (testados sem UI). Esconder links nao e a protecao.

### Como o OWNER e protegido
1. O e-mail fica so em `INITIAL_OWNER_EMAIL` (servidor). A autorizacao usa o papel gravado no banco.
2. `bootstrap_owner()` (SQL, `SECURITY DEFINER`) so executa para `service_role`, exige conta existente **com e-mail confirmado**, e idempotente, aceita **um unico OWNER** (indice unico) e audita sucesso e recusa.
3. Trigger `guard_profile_privileged_columns`: `anon`/`authenticated` nao alteram `role`/`status`/`email`; ninguem alem de `postgres`/`supabase_admin` promove, rebaixa ou suspende o OWNER, **nem o `service_role`** (portanto webhooks nao removem privilegios).
4. `role` nunca vem de `raw_user_meta_data` (editavel pelo usuario).
5. `audit_logs` e append-only (triggers bloqueiam UPDATE/DELETE/TRUNCATE).

### Acessar `/admin`
Entre com a conta OWNER (ou ADMIN com permissoes) e use o link "Administração" no dashboard, ou va direto a `/admin`. Visitantes anonimos vao para `/login`; contas comuns voltam a `/dashboard` com "Acesso negado".

## Testes (`npm test`)
- `tests/db/rls.test.ts` (34): isolamento por RLS, escalada de privilegio, bootstrap do OWNER, protecao do OWNER contra o proprio backend, auditoria imutavel. Roda as migracoes reais em PGlite com os papeis `anon/authenticated/service_role` e os privilegios padrao *permissivos* do Supabase, para provar que os `REVOKE` funcionam.
- `tests/unit/*` (58): matriz de permissoes, resolucao de plano (ativo, teste, atraso/carencia, cancelamento agendado, nao pago, OWNER), APIs admin (401/403/404/429/500, confirmacao, auditoria), checkout do OWNER, pausa do motor, favoritos/limites, rate limit, redirects/origem, paridade de chaves i18n.

## Limitacoes conhecidas
- Rate limit em memoria (por instancia): troque por Upstash/Vercel KV antes de escalar.
- Auditoria e gravada **depois** da acao (nao transacional); se falhar, a API responde 500 `audit_failed` e registra log estruturado. Evolucao: RPC transacional.
- Limite de favoritos tem janela de corrida entre requisicoes simultaneas do mesmo usuario.
- Sem politica de retencao de `audit_logs` ainda (a tabela e imutavel por projeto).
- Textos juridicos sao rascunho e exigem revisao juridica.
- Cabecalhos de seguranca basicos; falta CSP com nonce.

## Proximas fases
Stripe (Checkout, portal, webhooks assinados e idempotentes, tabela de eventos) → ingestao de dados + worker → motor multitemporal → historico/notificacoes → backtesting → observabilidade.
Ver `docs/DEPLOY.md` para checklist de deploy e rollback.
